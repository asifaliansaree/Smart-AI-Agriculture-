# ── STEP 1: Auto-install all required libraries ─────────────
import subprocess, sys

required_packages = [
    ("pandas", "pandas"),
    ("numpy", "numpy"),
    ("sklearn", "scikit-learn"),
    ("matplotlib", "matplotlib"),
    ("seaborn", "seaborn"),
    ("plotly", "plotly"),
    ("openpyxl", "openpyxl"),
    ("joblib", "joblib"),
    ("streamlit", "streamlit"),
    ("xgboost", "xgboost"),
    ("imbalanced_learn", "imbalanced-learn"),
]

for import_name, pip_name in required_packages:
    try:
        __import__(import_name)
    except ImportError:
        print(f"📦 Installing {pip_name}...")
        subprocess.check_call([sys.executable, "-m", "pip",
                               "install", pip_name, "-q"])
        print(f"✅ {pip_name} installed successfully")

# ── STEP 2: Import all libraries ────────────────────────────
import os
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge
from sklearn.svm import SVC
from sklearn.cluster import KMeans
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_curve, auc,
    mean_squared_error, mean_absolute_error,
    r2_score, silhouette_score
)

print("✅ All libraries loaded successfully\n")

# ============================================================
# File        : data_preprocessing.py
# Project     : Crop Disease Detection & Yield Prediction
# Semester    : 4th Semester Data Science
# Description : Loads, cleans and saves all 3 datasets
#
# IMPROVEMENTS:
#   - Detailed class distribution analysis for disease dataset
#   - IQR outlier detection documented for all datasets
#   - Feature statistics printed for transparency
#   - Preprocessing decisions explained in comments
# ============================================================

os.makedirs("eda_plots", exist_ok=True)

# ────────────────────────────────────────────────────────────
# ── DATASET 1: Wheat Disease (Dataset.xlsx) ────────────────
# ────────────────────────────────────────────────────────────

print("\n📂 Loading Wheat Disease Dataset...")
try:
    disease_df = pd.read_excel("Dataset.xlsx")
    print(f"   Shape: {disease_df.shape}")
    print(f"   Columns: {list(disease_df.columns)}")
    print(f"   Data types:\n{disease_df.dtypes}")
    print(f"   Missing values:\n{disease_df.isnull().sum()}")

    # Remove serial number column (not useful for ML)
    disease_df.drop('Sr#', axis=1, inplace=True)
    print("   ✓ Removed 'Sr#' column")

    # ── CLASS DISTRIBUTION ANALYSIS (IMPROVEMENT) ───────────
    # Critical: with only 43 samples and multiple classes,
    # class imbalance will seriously hurt model performance.
    # We document this explicitly for the report.
    print("\n   📊 Class Distribution Analysis (WheatDisease):")
    print(f"   {disease_df['WheatDisease'].value_counts()}")
    print(f"   Total samples: {len(disease_df)}")
    num_classes = disease_df['WheatDisease'].nunique()
    print(f"   Unique classes: {num_classes}")
    print(f"   ⚠️  Small dataset: {len(disease_df)} samples across {num_classes} classes")
    print(f"      → Cross-validation will be used instead of simple train/test split")
    print(f"      → SMOTE will handle class imbalance during model training")

    # ── OUTLIER DETECTION for disease dataset ───────────────
    # Using IQR method to check numeric features
    numeric_disease_cols = disease_df.select_dtypes(include=[np.number]).columns.tolist()
    # Remove target column from outlier check
    feature_cols_d = [c for c in numeric_disease_cols if c != 'WheatDisease']
    print(f"\n   📊 Outlier Detection (IQR method) on numeric features: {feature_cols_d}")
    for col in feature_cols_d:
        Q1 = disease_df[col].quantile(0.25)
        Q3 = disease_df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        n_out = ((disease_df[col] < lower) | (disease_df[col] > upper)).sum()
        print(f"      {col}: {n_out} outliers (kept — small dataset, removing could hurt)")

    # Encode categorical variables using LabelEncoder
    disease_encoders = {}
    categorical_cols = ['Part', 'Color', 'Apperance_Of_Part', 'WheatDisease']

    for col in categorical_cols:
        le = LabelEncoder()
        disease_df[col] = le.fit_transform(disease_df[col].astype(str))
        disease_encoders[col] = le
        print(f"   ✓ Encoded '{col}' ({len(le.classes_)} unique values: {list(le.classes_)})")

    # Save cleaned data and encoders
    disease_df.to_csv("cleaned_disease.csv", index=False)
    joblib.dump(disease_encoders, "disease_encoders.pkl")
    print(f"   ✓ Saved: cleaned_disease.csv")
    print(f"   ✓ Saved: disease_encoders.pkl")
    print(f"   ✓ Final shape: {disease_df.shape}")
    print("✅ Disease dataset cleaned and saved\n")

except Exception as e:
    print(f"❌ Error processing disease dataset: {e}\n")

# ────────────────────────────────────────────────────────────
# ── DATASET 2: Pakistan Yield (FAOSTAT CSV) ────────────────
# ── FIX: Cotton column now properly retained after pivot ────
# ────────────────────────────────────────────────────────────

print("📂 Loading Pakistan Yield Dataset...")
try:
    yield_raw = pd.read_csv("FAOSTAT_data_en_4-5-2026.csv")
    print(f"   Shape: {yield_raw.shape}")
    print(f"   Columns: {list(yield_raw.columns)}")
    print(f"   Unique Elements: {yield_raw['Element'].unique()}")
    print(f"   Unique Items (EXACT names): {yield_raw['Item'].unique()}")

    # Filter only Yield data rows
    yield_filtered = yield_raw[yield_raw['Element'] == 'Yield'].copy()
    print(f"   ✓ Filtered to Yield rows only: {yield_filtered.shape}")

    # Pivot table
    yield_df = yield_filtered.pivot_table(
        index='Year',
        columns='Item',
        values='Value',
        aggfunc='first'
    )
    yield_df.reset_index(inplace=True)

    # Clean column names carefully
    new_col_names = []
    for col in yield_df.columns:
        col_str = str(col).strip()
        if 'Cotton' in col_str:
            new_col_names.append('Cotton')
        elif 'Maize' in col_str:
            new_col_names.append('Maize')
        elif 'Rice' in col_str:
            new_col_names.append('Rice')
        elif 'Wheat' in col_str:
            new_col_names.append('Wheat')
        else:
            clean = col_str.replace(' ', '_').replace('(', '').replace(')', '')
            new_col_names.append(clean)

    yield_df.columns = new_col_names
    print(f"   ✓ Cleaned column names: {list(yield_df.columns)}")

    # Sort by year
    yield_df = yield_df.sort_values('Year').reset_index(drop=True)

    # ── OUTLIER DETECTION for yield dataset ─────────────────
    crop_cols_base = ['Wheat', 'Rice', 'Maize', 'Cotton']
    crop_cols_base = [c for c in crop_cols_base if c in yield_df.columns]
    print(f"\n   📊 Outlier Detection (IQR method) on yield features:")
    for col in crop_cols_base:
        Q1 = yield_df[col].quantile(0.25)
        Q3 = yield_df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        n_out = ((yield_df[col] < lower) | (yield_df[col] > upper)).sum()
        print(f"      {col}: {n_out} outliers (kept — time-series, outliers may be real events)")

    # Fill missing values
    yield_df.ffill(inplace=True)
    yield_df.bfill(inplace=True)
    print(f"\n   ✓ Filled missing values with ffill/bfill")
    print(f"   ✓ Missing values remaining: {yield_df.isnull().sum().sum()}")

    # Feature engineering
    yield_df['Year_norm'] = (yield_df['Year'] - yield_df['Year'].min()) / (
        yield_df['Year'].max() - yield_df['Year'].min()
    )
    for col in crop_cols_base:
        yield_df[col + '_roll3'] = yield_df[col].rolling(window=3, min_periods=1).mean()
    for col in crop_cols_base:
        yield_df[col + '_lag1'] = yield_df[col].shift(1)
    yield_df.fillna(0, inplace=True)

    yield_df.to_csv("cleaned_yield.csv", index=False)
    print(f"   ✓ Saved: cleaned_yield.csv")
    print(f"   ✓ Final shape: {yield_df.shape}")
    print(f"   ✓ Final columns: {list(yield_df.columns)}")
    print("✅ Yield dataset cleaned and saved\n")

except Exception as e:
    print(f"❌ Error processing yield dataset: {e}\n")

# ────────────────────────────────────────────────────────────
# ── DATASET 3: Raisin Classification (Raisin_Dataset.xlsx) ─
# ────────────────────────────────────────────────────────────

print("📂 Loading Raisin Dataset...")
try:
    raisin_df = pd.read_excel("Raisin_Dataset.xlsx")
    print(f"   Shape: {raisin_df.shape}")
    print(f"   Columns: {list(raisin_df.columns)}")
    print(f"   Missing values: {raisin_df.isnull().sum().sum()}")

    # Class distribution analysis
    print(f"\n   📊 Class Distribution (Raisin):")
    print(f"   {raisin_df['Class'].value_counts()}")

    # Encode Class column
    raisin_encoder = LabelEncoder()
    raisin_df['Class'] = raisin_encoder.fit_transform(raisin_df['Class'])
    joblib.dump(raisin_encoder, "raisin_encoder.pkl")
    print(f"   ✓ Encoded 'Class': {list(raisin_encoder.classes_)}")

    # Detect and document outliers using IQR
    numeric_cols = [c for c in raisin_df.columns if c != 'Class']
    total_outliers = 0
    print(f"\n   📊 Outlier Detection (IQR method):")
    for col in numeric_cols:
        Q1 = raisin_df[col].quantile(0.25)
        Q3 = raisin_df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        col_outliers = ((raisin_df[col] < lower) | (raisin_df[col] > upper)).sum()
        total_outliers += col_outliers
        print(f"      {col}: {col_outliers} outliers")
    print(f"   ✓ Total: {total_outliers} outliers (kept — adds natural variability)")

    # Feature statistics before scaling
    print(f"\n   📊 Feature Statistics (before scaling):")
    print(raisin_df[numeric_cols].describe().round(2))

    # Apply StandardScaler
    scaler = StandardScaler()
    raisin_df[numeric_cols] = scaler.fit_transform(raisin_df[numeric_cols])
    joblib.dump(scaler, "raisin_scaler.pkl")
    print(f"\n   ✓ Scaled {len(numeric_cols)} numeric features with StandardScaler")

    raisin_df.to_csv("cleaned_raisin.csv", index=False)
    print(f"   ✓ Saved: cleaned_raisin.csv")
    print(f"   ✓ Saved: raisin_scaler.pkl")
    print(f"   ✓ Final shape: {raisin_df.shape}")
    print("✅ Raisin dataset cleaned and saved\n")

except Exception as e:
    print(f"❌ Error processing raisin dataset: {e}\n")

# ────────────────────────────────────────────────────────────
# ── FINAL SUMMARY ───────────────────────────────────────────
# ────────────────────────────────────────────────────────────

print("\n" + "="*55)
print("    PREPROCESSING COMPLETE — SUMMARY")
print("="*55)
try:
    print(f"  1️⃣  Disease dataset  : {disease_df.shape}")
    print(f"       └─ File: cleaned_disease.csv")
    print(f"       └─ Encoders: disease_encoders.pkl")
    print(f"       └─ ⚠️  Small dataset ({len(disease_df)} rows) — CV will be used in training")
    print(f"\n  2️⃣  Yield dataset    : {yield_df.shape}")
    print(f"       └─ File: cleaned_yield.csv")
    print(f"       └─ Crops: {[c for c in yield_df.columns if c in ['Wheat','Rice','Maize','Cotton']]}")
    print(f"\n  3️⃣  Raisin dataset   : {raisin_df.shape}")
    print(f"       └─ File: cleaned_raisin.csv")
    print(f"       └─ Scaler: raisin_scaler.pkl")
except:
    pass
print("="*55)
print("\n✅ All preprocessing done! Run next: python eda.py\n")
