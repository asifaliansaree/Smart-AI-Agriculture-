# ── STEP 1: Auto-install all required libraries ─────────────
import subprocess, sys

required_packages = [
    ("pandas", "pandas"),
    ("numpy", "numpy"),
    ("sklearn", "scikit-learn"),
    ("matplotlib", "matplotlib"),
    ("seaborn", "seaborn"),
    ("plotly", "plotly"),
    ("openpyxl", "openpyxl"),
    ("joblib", "joblib"),
    ("streamlit", "streamlit"),
    ("xgboost", "xgboost"),
]

for import_name, pip_name in required_packages:
    try:
        __import__(import_name)
    except ImportError:
        print(f" Installing {pip_name}...")
        subprocess.check_call([sys.executable, "-m", "pip",
                               "install", pip_name, "-q"])
        print(f" {pip_name} installed successfully")

# ── STEP 2: Import all libraries ────────────────────────────
import os
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge
from sklearn.svm import SVC
from sklearn.cluster import KMeans
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_curve, auc,
    mean_squared_error, mean_absolute_error,
    r2_score, silhouette_score
)

print(" All libraries loaded successfully\n")

# ============================================================
# File        : eda.py
# Project     : Crop Disease Detection & Yield Prediction
# Semester    : 4th Semester Data Science
# Description : Exploratory Data Analysis — 13 visualizations
#
# IMPROVEMENTS ADDED:
#   - Class imbalance bar chart for disease dataset
#   - Yield correlation heatmap
#   - Raisin pairplot (class-separated)
#   - Model comparison bar chart placeholder
# ============================================================

os.makedirs("eda_plots", exist_ok=True)
print(" Created/verified eda_plots/ folder\n")

# ────────────────────────────────────────────────────────────
# ── LOAD ALL CLEANED DATASETS ──────────────────────────────
# ────────────────────────────────────────────────────────────

print(" Loading cleaned datasets...")
try:
    disease_df = pd.read_csv("cleaned_disease.csv")
    yield_df = pd.read_csv("cleaned_yield.csv")
    raisin_df = pd.read_csv("cleaned_raisin.csv")
    disease_encoders = joblib.load("disease_encoders.pkl")
    print(f"   ✓ Disease: {disease_df.shape}")
    print(f"   ✓ Yield: {yield_df.shape}")
    print(f"   ✓ Raisin: {raisin_df.shape}\n")
except Exception as e:
    print(f" Error loading datasets: {e}\n")
    exit()

# ────────────────────────────────────────────────────────────
# ── PLOT 1: Wheat Disease Distribution (Bar Chart) ────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 1: Disease Distribution...")
try:
    plt.figure(figsize=(10, 6))
    disease_labels = disease_encoders['WheatDisease'].inverse_transform(
        disease_df['WheatDisease'].unique()
    )
    disease_counts = disease_df['WheatDisease'].value_counts().sort_index()
    bars = plt.bar(range(len(disease_counts)), disease_counts.values, color='steelblue')
    plt.xticks(range(len(disease_counts)), disease_labels, rotation=45, ha='right')
    for i, (bar, val) in enumerate(zip(bars, disease_counts.values)):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1,
                 str(val), ha='center', fontweight='bold', fontsize=10)
    plt.xlabel('Disease Type', fontsize=12, fontweight='bold')
    plt.ylabel('Count', fontsize=12, fontweight='bold')
    plt.title('Wheat Disease Class Distribution\n(43 total samples — imbalanced dataset)',
              fontsize=13, fontweight='bold')
    plt.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig('eda_plots/disease_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: disease_distribution.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 2: Disease by Plant Part ─────────────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 2: Disease by Plant Part...")
try:
    plt.figure(figsize=(12, 6))
    vis_df = disease_df.copy()
    vis_df['Part'] = disease_encoders['Part'].inverse_transform(vis_df['Part'])
    vis_df['WheatDisease'] = disease_encoders['WheatDisease'].inverse_transform(
        vis_df['WheatDisease']
    )
    sns.countplot(data=vis_df, x='Part', hue='WheatDisease',
                  palette='Set2', ax=plt.gca())
    plt.xlabel('Plant Part', fontsize=12, fontweight='bold')
    plt.ylabel('Count', fontsize=12, fontweight='bold')
    plt.title('Disease Distribution by Plant Part', fontsize=14, fontweight='bold')
    plt.xticks(rotation=45, ha='right')
    plt.legend(title='Disease', bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig('eda_plots/disease_by_part.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: disease_by_part.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 3: Disease Correlation Heatmap ───────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 3: Disease Correlation Heatmap...")
try:
    plt.figure(figsize=(10, 8))
    corr_matrix = disease_df.corr()
    sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm',
                square=True, cbar_kws={'label': 'Correlation'})
    plt.title('Feature Correlation — Disease Dataset',
              fontsize=14, fontweight='bold', pad=20)
    plt.tight_layout()
    plt.savefig('eda_plots/disease_correlation.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: disease_correlation.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 4: Pakistan Crop Yield Trends ────────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 4: Yield Trends Over Time...")
try:
    plt.figure(figsize=(14, 7))
    crop_cols = [c for c in yield_df.columns
                 if c not in ['Year', 'Year_norm']
                 and not c.endswith('_lag1')
                 and not c.endswith('_roll3')]
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    for i, crop in enumerate(crop_cols):
        plt.plot(yield_df['Year'], yield_df[crop],
                marker='o', linewidth=2.5, label=crop,
                color=colors[i % len(colors)])
    plt.xlabel('Year', fontsize=12, fontweight='bold')
    plt.ylabel('Yield (hg/ha)', fontsize=12, fontweight='bold')
    plt.title('Pakistan Crop Yield Trend 2000–2024', fontsize=14, fontweight='bold')
    plt.legend(fontsize=11, loc='best')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('eda_plots/yield_trends.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: yield_trends.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 5: Average Yield Comparison ─────────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 5: Average Yield Comparison...")
try:
    plt.figure(figsize=(10, 6))
    crop_cols = [c for c in yield_df.columns
                 if c not in ['Year', 'Year_norm']
                 and not c.endswith('_lag1')
                 and not c.endswith('_roll3')]
    avg_yields = [yield_df[c].mean() for c in crop_cols]
    bars = plt.barh(crop_cols, avg_yields, color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'])
    for i, (bar, val) in enumerate(zip(bars, avg_yields)):
        plt.text(val, i, f' {val:.0f}', va='center', fontweight='bold')
    plt.xlabel('Average Yield (hg/ha)', fontsize=12, fontweight='bold')
    plt.title('Average Yield Comparison by Crop (2000–2024)',
              fontsize=14, fontweight='bold')
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    plt.savefig('eda_plots/avg_yield_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: avg_yield_comparison.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 6: Wheat Yield Focused Trend ────────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 6: Wheat Yield Trend...")
try:
    plt.figure(figsize=(14, 7))
    wheat_col = [c for c in yield_df.columns
                 if 'Wheat' in c
                 and not c.endswith('_lag1')
                 and not c.endswith('_roll3')][0]
    plt.plot(yield_df['Year'], yield_df[wheat_col],
            marker='o', linewidth=3, markersize=8,
            color='#d62728', label='Wheat Yield')
    # Add rolling mean trend line
    roll3 = yield_df[wheat_col].rolling(3, min_periods=1).mean()
    plt.plot(yield_df['Year'], roll3, linestyle='--', linewidth=2,
             color='navy', alpha=0.7, label='3-Year Rolling Average')
    plt.xlabel('Year', fontsize=12, fontweight='bold')
    plt.ylabel('Yield (hg/ha)', fontsize=12, fontweight='bold')
    plt.title('Pakistan Wheat Yield 2000–2024\n(with 3-year rolling average)',
              fontsize=13, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=11)
    plt.tight_layout()
    plt.savefig('eda_plots/wheat_yield_trend.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: wheat_yield_trend.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 7: Raisin Feature Distributions ──────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 7: Raisin Feature Distributions...")
try:
    numeric_cols = [c for c in raisin_df.columns if c != 'Class']
    fig, axes = plt.subplots(2, 4, figsize=(16, 10))
    axes = axes.flatten()
    for i, col in enumerate(numeric_cols):
        axes[i].hist(raisin_df[col], bins=30, color='steelblue',
                    edgecolor='black', alpha=0.7)
        axes[i].set_title(col, fontsize=11, fontweight='bold')
        axes[i].set_xlabel('Scaled Value', fontsize=10)
        axes[i].set_ylabel('Frequency', fontsize=10)
        axes[i].grid(axis='y', alpha=0.3)
    for i in range(len(numeric_cols), len(axes)):
        axes[i].set_visible(False)
    fig.suptitle('Feature Distributions — Raisin Dataset (StandardScaled)',
                fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('eda_plots/raisin_distributions.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: raisin_distributions.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 8: Raisin Boxplots by Class ──────────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 8: Raisin Feature Boxplots...")
try:
    numeric_cols = [c for c in raisin_df.columns if c != 'Class']
    fig, axes = plt.subplots(2, 4, figsize=(16, 10))
    axes = axes.flatten()
    for i, col in enumerate(numeric_cols):
        raisin_df_temp = raisin_df.copy()
        raisin_df_temp['Class'] = raisin_df_temp['Class'].astype(str)
        raisin_df_temp.boxplot(column=col, by='Class', ax=axes[i])
        axes[i].set_title(col, fontsize=11, fontweight='bold')
        axes[i].set_xlabel('Class (0=Kecimen, 1=Besni)', fontsize=9)
        axes[i].set_ylabel('Scaled Value', fontsize=10)
    for i in range(len(numeric_cols), len(axes)):
        axes[i].set_visible(False)
    fig.suptitle('Feature Boxplots by Raisin Class',
                fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('eda_plots/raisin_boxplots.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: raisin_boxplots.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 9: Raisin Correlation Heatmap ────────────────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 9: Raisin Correlation Heatmap...")
try:
    plt.figure(figsize=(11, 9))
    corr_matrix = raisin_df.corr()
    sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='YlOrRd',
                square=True, cbar_kws={'label': 'Correlation'})
    plt.title('Feature Correlation — Raisin Dataset',
              fontsize=14, fontweight='bold', pad=20)
    plt.tight_layout()
    plt.savefig('eda_plots/raisin_correlation.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: raisin_correlation.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 10 (NEW): Yield Feature Correlation Heatmap ──────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 10 (NEW): Yield Correlation Heatmap...")
try:
    crop_only_cols = [c for c in yield_df.columns
                      if c not in ['Year', 'Year_norm']
                      and not c.endswith('_lag1')
                      and not c.endswith('_roll3')]
    plt.figure(figsize=(8, 6))
    corr_yield = yield_df[crop_only_cols].corr()
    sns.heatmap(corr_yield, annot=True, fmt='.2f', cmap='coolwarm',
                square=True, cbar_kws={'label': 'Correlation'})
    plt.title('Crop Yield Inter-Correlation (Pakistan 2000–2024)',
              fontsize=13, fontweight='bold', pad=15)
    plt.tight_layout()
    plt.savefig('eda_plots/yield_correlation.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: yield_correlation.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 11 (NEW): Disease Class Imbalance Detail ─────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 11 (NEW): Disease Class Imbalance Analysis...")
try:
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    # Left: class counts
    disease_labels_full = disease_encoders['WheatDisease'].inverse_transform(
        sorted(disease_df['WheatDisease'].unique())
    )
    counts = disease_df['WheatDisease'].value_counts().sort_index()
    axes[0].barh(disease_labels_full, counts.values, color='steelblue')
    axes[0].set_xlabel('Sample Count', fontweight='bold')
    axes[0].set_title('Samples per Class', fontweight='bold', fontsize=12)
    for i, v in enumerate(counts.values):
        axes[0].text(v + 0.1, i, str(v), va='center', fontweight='bold')
    axes[0].grid(axis='x', alpha=0.3)

    # Right: class percentage pie
    axes[1].pie(counts.values, labels=disease_labels_full, autopct='%1.1f%%',
                startangle=90, colors=plt.cm.Set3.colors[:len(counts)])
    axes[1].set_title('Class Proportion (%)', fontweight='bold', fontsize=12)

    fig.suptitle('Wheat Disease Dataset — Class Imbalance Analysis\n'
                 '(43 total samples; imbalance motivates cross-validation + SMOTE)',
                 fontsize=12, fontweight='bold')
    plt.tight_layout()
    plt.savefig('eda_plots/disease_class_imbalance.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: disease_class_imbalance.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 12 (NEW): Raisin Class-Separated Scatter ─────────
# ────────────────────────────────────────────────────────────

print(" Creating Plot 12 (NEW): Raisin Class-Separated Feature Scatter...")
try:
    numeric_cols = [c for c in raisin_df.columns if c != 'Class']
    # Pick top 2 features (Area and MajorAxisLength typically most discriminating)
    feat1 = numeric_cols[0]
    feat2 = numeric_cols[1]

    plt.figure(figsize=(10, 7))
    colors_raisin = {0: '#1f77b4', 1: '#d62728'}
    labels_raisin = {0: 'Kecimen', 1: 'Besni'}
    for cls in [0, 1]:
        mask = raisin_df['Class'] == cls
        plt.scatter(raisin_df.loc[mask, feat1], raisin_df.loc[mask, feat2],
                    c=colors_raisin[cls], label=labels_raisin[cls],
                    alpha=0.5, s=25, edgecolors='none')
    plt.xlabel(feat1, fontsize=12, fontweight='bold')
    plt.ylabel(feat2, fontsize=12, fontweight='bold')
    plt.title(f'Raisin Class Separation: {feat1} vs {feat2}',
              fontsize=13, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig('eda_plots/raisin_class_scatter.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: raisin_class_scatter.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── PLOT 13 (NEW): Yield Feature Engineering Visualization ─
# ────────────────────────────────────────────────────────────

print(" Creating Plot 13 (NEW): Lag Feature vs Actual Yield...")
try:
    plt.figure(figsize=(10, 7))
    plt.scatter(yield_df['Wheat_lag1'], yield_df['Wheat'],
                color='forestgreen', s=80, edgecolors='black', linewidth=0.5, alpha=0.8)
    # Perfect prediction line
    mn = yield_df[['Wheat_lag1', 'Wheat']].min().min()
    mx = yield_df[['Wheat_lag1', 'Wheat']].max().max()
    plt.plot([mn, mx], [mn, mx], 'r--', linewidth=2, label='Perfect correlation line')
    plt.xlabel('Wheat Yield (Previous Year — lag1)', fontsize=12, fontweight='bold')
    plt.ylabel('Wheat Yield (Current Year)', fontsize=12, fontweight='bold')
    plt.title('Lag Feature Validation: Does Last Year Predict This Year?\n'
              '(Strong correlation justifies lag feature engineering)',
              fontsize=12, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig('eda_plots/lag_feature_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("   ✓ Saved: lag_feature_analysis.png\n")
except Exception as e:
    print(f"    Error: {e}\n")

# ────────────────────────────────────────────────────────────
# ── FINAL SUMMARY ──────────────────────────────────────────
# ────────────────────────────────────────────────────────────

print("\n" + "="*65)
print("    EDA COMPLETE — 13 PLOTS GENERATED")
print("="*65)
print("\n Plots saved to eda_plots/ folder:")
plots = [
    "disease_distribution.png",
    "disease_by_part.png",
    "disease_correlation.png",
    "yield_trends.png",
    "avg_yield_comparison.png",
    "wheat_yield_trend.png",
    "raisin_distributions.png",
    "raisin_boxplots.png",
    "raisin_correlation.png",
    "yield_correlation.png         ← NEW",
    "disease_class_imbalance.png   ← NEW",
    "raisin_class_scatter.png      ← NEW",
    "lag_feature_analysis.png      ← NEW",
]
for i, p in enumerate(plots, 1):
    print(f"   {i:2}. {p}")
print("="*65)
print("\n✅ EDA complete! Run next: python classification_models.py\n")
