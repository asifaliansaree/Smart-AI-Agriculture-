# ── STEP 1: Auto-install all required libraries ─────────────
import subprocess, sys
 
required_packages = [
    ("pandas", "pandas"),
    ("numpy", "numpy"),
    ("sklearn", "scikit-learn"),
    ("matplotlib", "matplotlib"),
    ("seaborn", "seaborn"),
    ("plotly", "plotly"),
    ("openpyxl", "openpyxl"),
    ("joblib", "joblib"),
    ("streamlit", "streamlit"),
    ("xgboost", "xgboost"),
]
 
for import_name, pip_name in required_packages:
    try:
        __import__(import_name)
    except ImportError:
        print(f"📦 Installing {pip_name}...")
        subprocess.check_call([sys.executable, "-m", "pip",
                               "install", pip_name, "-q"])
        print(f"✅ {pip_name} installed successfully")
 
# ── STEP 2: Import all libraries ────────────────────────────
import os
import warnings
warnings.filterwarnings('ignore')
 
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
 
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
 
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge
from sklearn.svm import SVC
from sklearn.cluster import KMeans
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_curve, auc,
    mean_squared_error, mean_absolute_error,
    r2_score, silhouette_score
)
 
# ============================================================
# File        : app.py
# Project     : Crop Disease Detection & Yield Prediction
# Semester    : 4th Semester Data Science
# Description : Interactive Streamlit web application
# ============================================================
 
st.set_page_config(
    page_title="Pakistan Crop Intelligence System",
    page_icon="🌾",
    layout="wide",
    initial_sidebar_state="expanded"
)
 
# ── MASTER STYLESHEET ────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=DM+Sans:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap');

/* ── ROOT VARIABLES ── */
:root {
    --bg-primary:     #07090B;
    --bg-secondary:   #0D1115;
    --bg-card:        #111518;
    --bg-card-hover:  #161C21;
    --bg-glass:       rgba(17,21,24,0.85);
    --border:         #1E262E;
    --border-mid:     #2A3540;
    --border-accent:  #9E7422;
    --gold:           #C9A84C;
    --gold-light:     #E2C97E;
    --gold-dim:       #7A5E1E;
    --gold-glow:      rgba(201,168,76,0.18);
    --text-primary:   #EDE8DF;
    --text-secondary: #8A96A3;
    --text-muted:     #4A5560;
    --green:          #3DB870;
    --green-bright:   #52D98A;
    --green-dim:      #162B20;
    --red:            #D94F4F;
    --red-bright:     #F06060;
    --red-dim:        #2E1515;
    --amber:          #D9982A;
    --amber-dim:      #2E2108;
    --blue:           #4888D4;
    --blue-bright:    #60A0E8;
    --blue-dim:       #101E30;
    --purple:         #8B68D4;
    --purple-dim:     #1A1428;
}

/* ── KEYFRAMES ── */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(16px); }
    to   { opacity: 1; transform: translateY(0); }
}
@keyframes shimmer {
    0%   { background-position: -400px 0; }
    100% { background-position: 400px 0; }
}
@keyframes pulseGold {
    0%, 100% { box-shadow: 0 0 0 0 rgba(201,168,76,0); }
    50%       { box-shadow: 0 0 0 6px rgba(201,168,76,0.08); }
}
@keyframes borderGlow {
    0%, 100% { border-color: rgba(201,168,76,0.15); }
    50%       { border-color: rgba(201,168,76,0.4); }
}
@keyframes dotPulse {
    0%, 100% { opacity: 0.4; transform: scale(1); }
    50%       { opacity: 1;   transform: scale(1.3); }
}

/* ── GLOBAL RESET ── */
html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif !important;
    background-color: var(--bg-primary) !important;
    color: var(--text-primary) !important;
    -webkit-font-smoothing: antialiased !important;
}

/* ── HIDE STREAMLIT CHROME (keep sidebar toggle!) ── */
#MainMenu { visibility: hidden; }
footer { visibility: hidden; }
.stDeployButton { display: none; }
header { background: transparent !important; }

/* ── FORCE SIDEBAR TOGGLE BUTTON VISIBLE ── */
[data-testid="collapsedControl"] {
    display: flex !important;
    visibility: visible !important;
    color: var(--gold) !important;
    background: rgba(201,168,76,0.12) !important;
    border: 1px solid rgba(201,168,76,0.3) !important;
    border-radius: 8px !important;
    padding: 4px !important;
    margin: 8px !important;
    cursor: pointer !important;
    z-index: 9999 !important;
}
[data-testid="collapsedControl"]:hover {
    background: rgba(201,168,76,0.22) !important;
}
/* Keep header visible so toggle works */
section[data-testid="stSidebar"] { display: block !important; visibility: visible !important; }

/* ── APP BACKGROUND ── */
.stApp {
    background-color: var(--bg-primary) !important;
    background-image:
        radial-gradient(ellipse 120% 60% at 50% -10%, rgba(201,168,76,0.055) 0%, transparent 55%),
        radial-gradient(ellipse 70% 50% at 95% 85%, rgba(72,136,212,0.04) 0%, transparent 50%),
        radial-gradient(ellipse 50% 40% at 5%  70%, rgba(61,184,112,0.025) 0%, transparent 50%);
}

/* ── SIDEBAR ── */
section[data-testid="stSidebar"] {
    min-width: 260px !important;
    max-width: 280px !important;
    display: block !important;
    visibility: visible !important;
}
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #080B0E 0%, #0C1014 40%, #0D1115 100%) !important;
    border-right: 1px solid var(--border) !important;
    box-shadow: 4px 0 30px rgba(0,0,0,0.5) !important;
}
[data-testid="stSidebar"]::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(201,168,76,0.35), transparent);
}
[data-testid="stSidebar"] .stRadio label {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 13.5px !important;
    font-weight: 400 !important;
    color: var(--text-secondary) !important;
    padding: 9px 14px !important;
    border-radius: 8px !important;
    transition: all 0.22s ease !important;
    cursor: pointer !important;
    display: block !important;
    border: 1px solid transparent !important;
    margin: 1px 0 !important;
}
[data-testid="stSidebar"] .stRadio label:hover {
    color: var(--gold-light) !important;
    background: rgba(201,168,76,0.07) !important;
    border-color: rgba(201,168,76,0.12) !important;
}
[data-testid="stSidebar"] .stRadio [aria-checked="true"] + label,
[data-testid="stSidebar"] .stRadio input:checked + div label {
    color: var(--gold) !important;
    background: rgba(201,168,76,0.1) !important;
    border-color: rgba(201,168,76,0.2) !important;
    font-weight: 500 !important;
}

/* ── MAIN CONTENT AREA ── */
.main .block-container {
    padding: 2.5rem 3.5rem 5rem 3.5rem !important;
    max-width: 1440px !important;
}

/* ── PAGE HEADER ── */
.page-header {
    position: relative;
    padding-bottom: 2rem;
    margin-bottom: 3rem;
    animation: fadeInUp 0.5s ease both;
}
.page-header::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, var(--gold-dim), rgba(201,168,76,0.15) 40%, transparent);
}
.page-title {
    font-family: 'Cormorant Garamond', serif !important;
    font-size: 3.2rem !important;
    font-weight: 600 !important;
    color: var(--text-primary) !important;
    letter-spacing: -0.025em !important;
    line-height: 1.08 !important;
    margin: 0.5rem 0 0.5rem 0 !important;
    background: linear-gradient(135deg, #EDE8DF 0%, #C9A84C 60%, #E2C97E 100%);
    -webkit-background-clip: text !important;
    -webkit-text-fill-color: transparent !important;
    background-clip: text !important;
}
.page-subtitle {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.95rem !important;
    color: var(--text-muted) !important;
    font-weight: 300 !important;
    letter-spacing: 0.025em !important;
    margin-top: 0.2rem !important;
}
.gold-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-family: 'Space Mono', monospace;
    font-size: 9.5px;
    font-weight: 700;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: var(--gold);
    background: linear-gradient(135deg, rgba(201,168,76,0.1), rgba(201,168,76,0.05));
    border: 1px solid rgba(201,168,76,0.22);
    padding: 5px 12px;
    border-radius: 4px;
    margin-bottom: 0.9rem;
}
.gold-tag::before {
    content: '';
    width: 5px; height: 5px;
    border-radius: 50%;
    background: var(--gold);
    animation: dotPulse 2s ease infinite;
}

/* ── CARDS ── */
.elegantcard {
    background: linear-gradient(145deg, var(--bg-card) 0%, rgba(13,17,21,0.95) 100%);
    border: 1px solid var(--border-mid);
    border-radius: 14px;
    padding: 1.6rem 1.8rem;
    margin-bottom: 1.2rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}
.elegantcard::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(201,168,76,0.25), transparent);
}
.elegantcard:hover {
    border-color: rgba(201,168,76,0.28);
    box-shadow: 0 8px 40px rgba(0,0,0,0.5), 0 0 0 1px rgba(201,168,76,0.06),
                inset 0 1px 0 rgba(201,168,76,0.05);
    transform: translateY(-2px);
}

/* ── STAT / METRIC CARDS ── */
.stat-card {
    background: linear-gradient(145deg, var(--bg-card) 0%, #0D1115 100%);
    border: 1px solid var(--border-mid);
    border-top: 2px solid var(--gold-dim);
    border-radius: 12px;
    padding: 1.6rem 1.4rem;
    text-align: center;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    animation: fadeInUp 0.5s ease both;
}
.stat-card::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 40%;
    background: radial-gradient(ellipse at 50% 100%, rgba(201,168,76,0.04) 0%, transparent 70%);
    pointer-events: none;
}
.stat-card:hover {
    border-top-color: var(--gold);
    box-shadow: 0 6px 30px rgba(0,0,0,0.4), 0 0 20px rgba(201,168,76,0.06);
    transform: translateY(-3px);
}
.stat-label {
    font-family: 'Space Mono', monospace;
    font-size: 8.5px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: var(--text-muted);
    margin-bottom: 0.7rem;
}
.stat-value {
    font-family: 'Cormorant Garamond', serif;
    font-size: 2.8rem;
    font-weight: 700;
    background: linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
    margin-bottom: 0.4rem;
}
.stat-delta {
    font-size: 11px;
    color: var(--text-muted);
    font-weight: 400;
    line-height: 1.5;
}

/* ── INFO / ALERT BOXES ── */
.info-box {
    background: linear-gradient(135deg, rgba(72,136,212,0.07), rgba(72,136,212,0.03));
    border: 1px solid rgba(72,136,212,0.22);
    border-left: 3px solid var(--blue);
    border-radius: 10px;
    padding: 1.1rem 1.4rem;
    margin: 1.2rem 0;
    color: var(--text-primary);
    font-size: 0.9rem;
    line-height: 1.75;
    position: relative;
}
.success-box {
    background: linear-gradient(135deg, rgba(61,184,112,0.07), rgba(61,184,112,0.03));
    border: 1px solid rgba(61,184,112,0.22);
    border-left: 3px solid var(--green);
    border-radius: 10px;
    padding: 1.1rem 1.4rem;
    margin: 1.2rem 0;
    color: var(--text-primary);
    font-size: 0.9rem;
    line-height: 1.75;
}
.warning-box {
    background: linear-gradient(135deg, rgba(217,152,42,0.07), rgba(217,152,42,0.03));
    border: 1px solid rgba(217,152,42,0.22);
    border-left: 3px solid var(--amber);
    border-radius: 10px;
    padding: 1.1rem 1.4rem;
    margin: 1.2rem 0;
    color: var(--text-primary);
    font-size: 0.9rem;
    line-height: 1.75;
}
.error-box {
    background: linear-gradient(135deg, rgba(217,79,79,0.07), rgba(217,79,79,0.03));
    border: 1px solid rgba(217,79,79,0.22);
    border-left: 3px solid var(--red);
    border-radius: 10px;
    padding: 1.1rem 1.4rem;
    margin: 1.2rem 0;
    color: var(--text-primary);
    font-size: 0.9rem;
    line-height: 1.75;
}

/* ── OVERRIDE STREAMLIT NATIVE ALERTS ── */
.stAlert {
    background: linear-gradient(135deg, rgba(72,136,212,0.07), rgba(72,136,212,0.03)) !important;
    border: 1px solid rgba(72,136,212,0.22) !important;
    border-left: 3px solid var(--blue) !important;
    border-radius: 10px !important;
    color: var(--text-primary) !important;
}
div[data-testid="stNotification"] {
    background: var(--bg-card) !important;
    border: 1px solid var(--border-mid) !important;
}

/* ── BUTTONS ── */
.stButton > button {
    background: var(--bg-card) !important;
    color: var(--text-secondary) !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 12.5px !important;
    font-weight: 500 !important;
    letter-spacing: 0.02em !important;
    border: 1px solid var(--border-mid) !important;
    border-radius: 8px !important;
    padding: 0.5rem 0.8rem !important;
    transition: all 0.22s ease !important;
    box-shadow: none !important;
    white-space: nowrap !important;
}
.stButton > button:hover {
    color: var(--gold-light) !important;
    border-color: rgba(201,168,76,0.3) !important;
    background: rgba(201,168,76,0.07) !important;
    box-shadow: none !important;
    transform: none !important;
}
/* Primary (active page) button */
.stButton > button[kind="primary"],
button[data-testid="baseButton-primary"] {
    background: linear-gradient(135deg, rgba(201,168,76,0.18), rgba(201,168,76,0.1)) !important;
    color: var(--gold-light) !important;
    border-color: rgba(201,168,76,0.4) !important;
    font-weight: 600 !important;
    box-shadow: 0 2px 12px rgba(201,168,76,0.15) !important;
}
button[data-testid="baseButton-primary"]:hover {
    background: linear-gradient(135deg, rgba(201,168,76,0.25), rgba(201,168,76,0.15)) !important;
    box-shadow: 0 4px 18px rgba(201,168,76,0.22) !important;
}

/* ── SELECT / INPUT ── */
.stSelectbox > div > div,
.stMultiSelect > div > div {
    background: var(--bg-card) !important;
    border: 1px solid var(--border-mid) !important;
    border-radius: 9px !important;
    color: var(--text-primary) !important;
    font-family: 'DM Sans', sans-serif !important;
    transition: all 0.2s ease !important;
}
.stSelectbox > div > div:focus-within,
.stMultiSelect > div > div:focus-within {
    border-color: var(--gold-dim) !important;
    box-shadow: 0 0 0 3px rgba(201,168,76,0.1) !important;
}
.stTextInput > div > div > input,
.stNumberInput > div > div > input {
    background: var(--bg-card) !important;
    border: 1px solid var(--border-mid) !important;
    border-radius: 9px !important;
    color: var(--text-primary) !important;
    font-family: 'DM Sans', sans-serif !important;
    transition: all 0.2s ease !important;
    padding: 0.5rem 0.85rem !important;
}
.stTextInput > div > div > input:focus,
.stNumberInput > div > div > input:focus {
    border-color: var(--gold-dim) !important;
    box-shadow: 0 0 0 3px rgba(201,168,76,0.1) !important;
    outline: none !important;
}
.stTextInput label, .stNumberInput label,
.stSelectbox label, .stMultiSelect label {
    font-family: 'Space Mono', monospace !important;
    font-size: 9px !important;
    letter-spacing: 0.15em !important;
    text-transform: uppercase !important;
    color: var(--text-muted) !important;
    margin-bottom: 4px !important;
}

/* ── SLIDER ── */
.stSlider > div > div > div {
    background: var(--border-mid) !important;
    height: 3px !important;
    border-radius: 2px !important;
}
.stSlider > div > div > div > div {
    background: linear-gradient(90deg, var(--gold-dim), var(--gold)) !important;
    border-radius: 2px !important;
}
.stSlider > div > div > div > div > div {
    background: var(--gold) !important;
    border: 2px solid var(--bg-primary) !important;
    box-shadow: 0 0 10px rgba(201,168,76,0.5), 0 0 0 3px rgba(201,168,76,0.15) !important;
    width: 16px !important; height: 16px !important;
    transition: box-shadow 0.2s !important;
}

/* ── TABS ── */
.stTabs [data-baseweb="tab-list"] {
    background: rgba(17,21,24,0.8) !important;
    border-radius: 11px !important;
    padding: 5px !important;
    border: 1px solid var(--border-mid) !important;
    gap: 3px !important;
    backdrop-filter: blur(10px) !important;
}
.stTabs [data-baseweb="tab"] {
    background: transparent !important;
    color: var(--text-muted) !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    border-radius: 8px !important;
    padding: 9px 20px !important;
    border: 1px solid transparent !important;
    letter-spacing: 0.01em !important;
    transition: all 0.25s ease !important;
}
.stTabs [data-baseweb="tab"]:hover {
    color: var(--text-secondary) !important;
    background: rgba(255,255,255,0.04) !important;
}
.stTabs [aria-selected="true"] {
    background: linear-gradient(135deg, rgba(201,168,76,0.15), rgba(201,168,76,0.08)) !important;
    color: var(--gold-light) !important;
    font-weight: 600 !important;
    border-color: rgba(201,168,76,0.2) !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3) !important;
}
.stTabs [data-baseweb="tab-panel"] {
    padding-top: 1.8rem !important;
}

/* ── DATAFRAMES / TABLES ── */
.stDataFrame {
    background: var(--bg-card) !important;
    border: 1px solid var(--border-mid) !important;
    border-radius: 12px !important;
    overflow: hidden !important;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3) !important;
}
.stDataFrame iframe {
    background: transparent !important;
}
.stDataFrame thead tr th {
    background: rgba(201,168,76,0.07) !important;
    font-family: 'Space Mono', monospace !important;
    font-size: 9px !important;
    letter-spacing: 0.15em !important;
    color: var(--gold) !important;
    text-transform: uppercase !important;
}

/* ── METRICS (native) ── */
[data-testid="metric-container"] {
    background: linear-gradient(145deg, var(--bg-card), #0D1115) !important;
    border: 1px solid var(--border-mid) !important;
    border-top: 2px solid var(--gold-dim) !important;
    border-radius: 12px !important;
    padding: 1.2rem 1.4rem !important;
    transition: all 0.3s ease !important;
    position: relative !important;
    overflow: hidden !important;
}
[data-testid="metric-container"]::after {
    content: '' !important;
    position: absolute !important;
    bottom: 0; left: 0; right: 0 !important;
    height: 30% !important;
    background: radial-gradient(ellipse at 50% 100%, rgba(201,168,76,0.04) 0%, transparent 70%) !important;
}
[data-testid="metric-container"]:hover {
    border-top-color: var(--gold) !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 25px rgba(0,0,0,0.35) !important;
}
[data-testid="metric-container"] [data-testid="stMetricLabel"] {
    font-family: 'Space Mono', monospace !important;
    font-size: 8.5px !important;
    letter-spacing: 0.18em !important;
    text-transform: uppercase !important;
    color: var(--text-muted) !important;
}
[data-testid="metric-container"] [data-testid="stMetricValue"] {
    font-family: 'Cormorant Garamond', serif !important;
    font-size: 2.2rem !important;
    background: linear-gradient(135deg, var(--gold), var(--gold-light)) !important;
    -webkit-background-clip: text !important;
    -webkit-text-fill-color: transparent !important;
    background-clip: text !important;
}
[data-testid="metric-container"] [data-testid="stMetricDelta"] {
    font-size: 11px !important;
    color: var(--text-muted) !important;
}

/* ── PROGRESS BAR ── */
.stProgress > div > div > div {
    background: linear-gradient(90deg, var(--gold-dim), var(--gold), var(--gold-light)) !important;
    background-size: 200% auto !important;
    border-radius: 4px !important;
    animation: shimmer 2s linear infinite !important;
}
.stProgress > div > div {
    background: var(--border-mid) !important;
    border-radius: 4px !important;
    height: 5px !important;
}

/* ── SPINNER ── */
.stSpinner > div {
    border-top-color: var(--gold) !important;
}
div[data-testid="stSpinner"] > div {
    border-color: var(--border-mid) transparent transparent transparent !important;
}

/* ── DIVIDER ── */
hr {
    border: none !important;
    height: 1px !important;
    background: linear-gradient(90deg, var(--gold-dim), rgba(201,168,76,0.1) 50%, transparent) !important;
    margin: 2.5rem 0 !important;
}

/* ── HEADINGS ── */
h1, h2, h3, h4 {
    font-family: 'Cormorant Garamond', serif !important;
    font-weight: 600 !important;
    color: var(--text-primary) !important;
    letter-spacing: -0.02em !important;
}
h1 { font-size: 3rem !important; }
h2 { font-size: 2rem !important; }
h3 { font-size: 1.6rem !important; }

/* ── CAPTION / SMALL TEXT ── */
.stCaption, small, .caption {
    color: var(--text-muted) !important;
    font-size: 11.5px !important;
}

/* ── SIDEBAR TITLE ── */
.sidebar-brand {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 0.5rem 0 1.2rem 0;
    border-bottom: 1px solid rgba(201,168,76,0.12);
    margin-bottom: 1.2rem;
}
.sidebar-brand-icon {
    width: 38px; height: 38px;
    border-radius: 10px;
    background: linear-gradient(135deg, rgba(201,168,76,0.15), rgba(201,168,76,0.05));
    border: 1px solid rgba(201,168,76,0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    flex-shrink: 0;
}
.sidebar-brand-name {
    font-family: 'Cormorant Garamond', serif;
    font-size: 1.15rem;
    font-weight: 600;
    color: var(--text-primary);
    line-height: 1.2;
}
.sidebar-brand-sub {
    font-family: 'Space Mono', monospace;
    font-size: 9px;
    color: var(--text-muted);
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin-top: 2px;
}

/* ── RESULT CARDS ── */
.result-disease {
    background: linear-gradient(135deg, var(--red-dim), rgba(30,15,15,0.8));
    border: 1px solid rgba(217,79,79,0.3);
    border-left: 4px solid var(--red);
    border-radius: 12px;
    padding: 1.6rem;
    margin: 1.2rem 0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3), 0 0 30px rgba(217,79,79,0.06);
    animation: fadeInUp 0.4s ease both;
}
.result-healthy {
    background: linear-gradient(135deg, var(--green-dim), rgba(15,30,20,0.8));
    border: 1px solid rgba(61,184,112,0.3);
    border-left: 4px solid var(--green);
    border-radius: 12px;
    padding: 1.6rem;
    margin: 1.2rem 0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3), 0 0 30px rgba(61,184,112,0.06);
    animation: fadeInUp 0.4s ease both;
}
.result-label {
    font-family: 'Space Mono', monospace;
    font-size: 9.5px;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: var(--text-muted);
    margin-bottom: 0.5rem;
}
.result-value {
    font-family: 'Cormorant Garamond', serif;
    font-size: 2rem;
    font-weight: 700;
    color: var(--text-primary);
    line-height: 1.2;
}

/* ── CONFIDENCE BADGE ── */
.conf-badge-high {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: rgba(61,184,112,0.12);
    border: 1px solid rgba(61,184,112,0.32);
    color: var(--green-bright);
    font-family: 'Space Mono', monospace;
    font-size: 9.5px;
    letter-spacing: 0.1em;
    padding: 4px 12px;
    border-radius: 4px;
    text-transform: uppercase;
}
.conf-badge-med {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: rgba(217,152,42,0.12);
    border: 1px solid rgba(217,152,42,0.32);
    color: var(--amber);
    font-family: 'Space Mono', monospace;
    font-size: 9.5px;
    letter-spacing: 0.1em;
    padding: 4px 12px;
    border-radius: 4px;
    text-transform: uppercase;
}
.conf-badge-low {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: rgba(217,79,79,0.12);
    border: 1px solid rgba(217,79,79,0.32);
    color: var(--red-bright);
    font-family: 'Space Mono', monospace;
    font-size: 9.5px;
    letter-spacing: 0.1em;
    padding: 4px 12px;
    border-radius: 4px;
    text-transform: uppercase;
}

/* ── CLUSTER ZONE CARDS ── */
.zone-card {
    border-radius: 14px;
    padding: 1.6rem;
    margin-bottom: 0.6rem;
    border: 1px solid;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}
.zone-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, currentColor, transparent);
    opacity: 0.3;
}
.zone-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.4);
}
.zone-card-label {
    font-family: 'Space Mono', monospace;
    font-size: 9.5px;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    margin-bottom: 0.7rem;
    opacity: 0.65;
}
.zone-card-title {
    font-family: 'Cormorant Garamond', serif;
    font-size: 1.35rem;
    font-weight: 600;
    margin-bottom: 0.9rem;
    line-height: 1.2;
}
.zone-card-stat {
    font-size: 12.5px;
    color: var(--text-secondary);
    margin: 5px 0;
    line-height: 1.6;
}

/* ── TABLE STYLING IN MARKDOWN ── */
table {
    border-collapse: collapse !important;
    width: 100% !important;
    font-size: 13px !important;
    border-radius: 10px !important;
    overflow: hidden !important;
    background: var(--bg-card) !important;
    box-shadow: 0 4px 20px rgba(0,0,0,0.25) !important;
}
thead tr {
    background: linear-gradient(90deg, rgba(201,168,76,0.1), rgba(201,168,76,0.05)) !important;
    border-bottom: 1px solid rgba(201,168,76,0.2) !important;
}
th {
    font-family: 'Space Mono', monospace !important;
    font-size: 8.5px !important;
    letter-spacing: 0.18em !important;
    text-transform: uppercase !important;
    color: var(--gold) !important;
    padding: 12px 16px !important;
    text-align: left !important;
}
td {
    padding: 10px 16px !important;
    color: var(--text-secondary) !important;
    border-bottom: 1px solid var(--border) !important;
}
tbody tr:hover { background: rgba(255,255,255,0.025) !important; }

/* ── SECTION LABEL ── */
.section-eyebrow {
    font-family: 'Space Mono', monospace;
    font-size: 8.5px;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    color: var(--gold);
    margin-bottom: 0.6rem;
    opacity: 0.8;
}
.section-title {
    font-family: 'Cormorant Garamond', serif;
    font-size: 1.7rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 1.1rem;
    letter-spacing: -0.01em;
    line-height: 1.2;
}

/* ── FOOTER ── */
.app-footer {
    text-align: center;
    padding: 2.5rem 0 1.5rem 0;
    margin-top: 4rem;
    position: relative;
}
.app-footer::before {
    content: '';
    position: absolute;
    top: 0; left: 10%; right: 10%;
    height: 1px;
    background: linear-gradient(90deg, transparent, var(--gold-dim), rgba(201,168,76,0.15) 50%, transparent);
}
.app-footer-text {
    font-family: 'Space Mono', monospace;
    font-size: 9.5px;
    letter-spacing: 0.14em;
    color: var(--text-muted);
    text-transform: uppercase;
    line-height: 2.2;
}

/* ── PLOTLY CHART CONTAINER ── */
.stPlotlyChart {
    background: linear-gradient(145deg, var(--bg-card), #0D1115) !important;
    border: 1px solid var(--border-mid) !important;
    border-radius: 14px !important;
    overflow: hidden !important;
    padding: 0.75rem !important;
    box-shadow: 0 6px 30px rgba(0,0,0,0.35) !important;
    transition: box-shadow 0.3s ease !important;
}
.stPlotlyChart:hover {
    box-shadow: 0 8px 40px rgba(0,0,0,0.45), 0 0 0 1px rgba(201,168,76,0.08) !important;
}

/* ── SIDEBAR INFO BOX ── */
.sidebar-info {
    background: linear-gradient(135deg, rgba(201,168,76,0.07), rgba(201,168,76,0.03));
    border: 1px solid rgba(201,168,76,0.14);
    border-radius: 10px;
    padding: 14px 16px;
    font-size: 11px;
    color: var(--text-muted);
    line-height: 1.8;
    margin-top: 1.2rem;
}

/* ── RADIO BUTTON DOTS ── */
.stRadio > div { gap: 2px !important; }

/* ── SCROLLBAR ── */
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: var(--bg-primary); }
::-webkit-scrollbar-thumb {
    background: var(--border-mid);
    border-radius: 3px;
}
::-webkit-scrollbar-thumb:hover { background: var(--gold-dim); }

/* ── CHECKBOX ── */
.stCheckbox label {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 13px !important;
    color: var(--text-secondary) !important;
    transition: color 0.2s !important;
}
.stCheckbox label:hover { color: var(--text-primary) !important; }

/* ── COLUMN GAPS ── */
[data-testid="column"] { gap: 1.2rem; }

/* ── LOADING SPINNER OVERRIDE ── */
.stSpinner { padding: 2rem; text-align: center; }

</style>
""", unsafe_allow_html=True)
 
# ── PLOTLY DEFAULT THEME ─────────────────────────────────────
PLOTLY_LAYOUT = dict(
    paper_bgcolor='rgba(0,0,0,0)',
    plot_bgcolor='rgba(0,0,0,0)',
    font=dict(family='DM Sans', color='#8A96A3', size=12),
    title_font=dict(family='Cormorant Garamond', color='#EDE8DF', size=20),
    xaxis=dict(
        gridcolor='rgba(30,38,46,0.8)', linecolor='#1E262E',
        tickfont=dict(color='#4A5560', size=11),
        title_font=dict(color='#8A96A3', size=12),
        showgrid=True, zeroline=False,
    ),
    yaxis=dict(
        gridcolor='rgba(30,38,46,0.8)', linecolor='#1E262E',
        tickfont=dict(color='#4A5560', size=11),
        title_font=dict(color='#8A96A3', size=12),
        showgrid=True, zeroline=False,
    ),
    legend=dict(
        bgcolor='rgba(13,17,21,0.9)', bordercolor='#2A3540',
        borderwidth=1, font=dict(color='#8A96A3', size=11),
        itemsizing='constant',
    ),
    margin=dict(l=20, r=20, t=55, b=20),
    hovermode='x unified',
    hoverlabel=dict(
        bgcolor='rgba(13,17,21,0.95)',
        bordercolor='rgba(201,168,76,0.3)',
        font=dict(family='DM Sans', color='#EDE8DF', size=12),
    ),
)
 
GOLD_COLORS = ['#C9A84C', '#4A90D9', '#4CAF7D', '#E05555', '#E8A838', '#8A6A2A']
 
# ────────────────────────────────────────────────────────────
# ── SESSION STATE NAVIGATION ──────────────────────────────
# ────────────────────────────────────────────────────────────

PAGES = [
    ("🏠", "Home",             "🏠 Home"),
    ("📊", "Model Dashboard",  "📊 Model Performance Dashboard"),
    ("🔬", "Disease Checker",  "🔬 Disease Risk Checker"),
    ("📈", "Yield Predictor",  "📈 Yield Predictor"),
    ("🗺️", "Zone Insights",   "🗺️ Crop Zone Insights"),
    ("🔍", "Comparative",      "🔍 Comparative Analysis"),
]

if "page_index" not in st.session_state:
    st.session_state.page_index = 0

# ── SIDEBAR NAVIGATION ───────────────────────────────────
# Override ALL sidebar + toggle CSS so it is always visible and fully styled
st.markdown("""
<style>
/* ── FORCE SIDEBAR ALWAYS OPEN & VISIBLE ── */
section[data-testid="stSidebar"] {
    display: flex !important;
    visibility: visible !important;
    opacity: 1 !important;
    width: 270px !important;
    min-width: 270px !important;
    max-width: 270px !important;
    transform: none !important;
    transition: none !important;
}
section[data-testid="stSidebar"] > div {
    width: 270px !important;
    min-width: 270px !important;
}
/* Hide the collapse arrow — sidebar is always open */
[data-testid="collapsedControl"] { display: none !important; }

/* ── NAV BUTTON OVERRIDES (sidebar only) ── */
section[data-testid="stSidebar"] .stButton > button {
    background: transparent !important;
    color: #8A96A3 !important;
    border: 1px solid transparent !important;
    border-radius: 9px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 13.5px !important;
    font-weight: 400 !important;
    letter-spacing: 0.01em !important;
    padding: 10px 14px !important;
    text-align: left !important;
    width: 100% !important;
    margin: 1px 0 !important;
    box-shadow: none !important;
    transition: all 0.2s ease !important;
}
section[data-testid="stSidebar"] .stButton > button:hover {
    color: #E2C97E !important;
    background: rgba(201,168,76,0.07) !important;
    border-color: rgba(201,168,76,0.15) !important;
    transform: none !important;
    box-shadow: none !important;
}
section[data-testid="stSidebar"] button[data-testid="baseButton-primary"] {
    background: linear-gradient(135deg, rgba(201,168,76,0.14), rgba(201,168,76,0.07)) !important;
    color: #C9A84C !important;
    border-color: rgba(201,168,76,0.3) !important;
    font-weight: 600 !important;
    box-shadow: none !important;
}

/* ── MAIN CONTENT — restore normal padding ── */
.main .block-container {
    padding-top: 2.5rem !important;
}
</style>
""", unsafe_allow_html=True)

with st.sidebar:
    # Brand header
    st.markdown("""
    <div style="display:flex;align-items:center;gap:11px;padding:0.6rem 0 1.2rem 0;
    border-bottom:1px solid rgba(201,168,76,0.15);margin-bottom:1.2rem;">
        <div style="font-size:20px;background:rgba(201,168,76,0.12);
        border:1px solid rgba(201,168,76,0.25);border-radius:9px;
        width:40px;height:40px;display:flex;align-items:center;
        justify-content:center;flex-shrink:0;">🌾</div>
        <div>
            <div style="font-family:'Cormorant Garamond',serif;font-size:1.05rem;
            font-weight:600;color:#EDE8DF;line-height:1.2;">Crop Intelligence</div>
            <div style="font-family:'Space Mono',monospace;font-size:8px;
            letter-spacing:0.1em;text-transform:uppercase;color:#4A5560;
            margin-top:2px;">Pakistan · AI System</div>
        </div>
    </div>
    <div style="font-family:'Space Mono',monospace;font-size:8.5px;letter-spacing:0.2em;
    text-transform:uppercase;color:#C9A84C;opacity:0.7;margin-bottom:8px;">Navigation</div>
    """, unsafe_allow_html=True)

    # Navigation buttons
    for i, (icon, label, _) in enumerate(PAGES):
        is_active = (st.session_state.page_index == i)
        if st.button(
            f"{icon}  {label}",
            key=f"nav_{i}",
            use_container_width=True,
            type="primary" if is_active else "secondary",
        ):
            st.session_state.page_index = i
            st.rerun()

    # Footer info
    st.markdown("""
    <div style="margin-top:1.5rem;padding-top:1rem;border-top:1px solid rgba(201,168,76,0.1);">
    <div style="background:linear-gradient(135deg,rgba(201,168,76,0.07),rgba(201,168,76,0.03));
    border:1px solid rgba(201,168,76,0.13);border-radius:10px;padding:13px 15px;
    font-size:11px;color:#4A5560;line-height:1.8;">
        CS-245 Machine Learning Project<br>
        4th Semester · Data Science<br>
        <span style="color:#C9A84C;">◆</span> Classification &nbsp;
        <span style="color:#4A90D9;">◆</span> Regression &nbsp;
        <span style="color:#4CAF7D;">◆</span> Clustering
    </div>
    </div>
    """, unsafe_allow_html=True)

# Resolve current page string
page = PAGES[st.session_state.page_index][2]
 
# ────────────────────────────────────────────────────────────
# ── HOME PAGE ─────────────────────────────────────────────
# ────────────────────────────────────────────────────────────
 
if page == "🏠 Home":
    st.markdown("""
    <div class="page-header">
        <div class="gold-tag">Pakistan Crop Intelligence System</div>
        <div class="page-title">AI-Powered Agricultural<br>Decision Intelligence</div>
        <div class="page-subtitle">Machine Learning for Crop Disease Detection · Yield Forecasting · Zone Analysis</div>
    </div>
    """, unsafe_allow_html=True)
 
    # Welcome text
    st.markdown("""
    <div class="elegantcard">
        <div class="section-eyebrow">Overview</div>
        <p style="color: var(--text-secondary); line-height: 1.9; font-size: 0.97rem; margin: 0;">
        Welcome to the <strong style="color:var(--text-primary);">Pakistan Crop Intelligence System</strong> — 
        an integrated machine learning platform combining multiple AI models trained on real agricultural data 
        to support data-driven decisions for farmers and agricultural experts. The system covers disease detection, 
        yield forecasting, temporal clustering, and full model transparency reporting.
        </p>
    </div>
    """, unsafe_allow_html=True)
 
    # Stat cards
    st.markdown('<div class="section-eyebrow" style="margin-top:2rem;">System Metrics</div>', unsafe_allow_html=True)
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        st.markdown("""
        <div class="stat-card">
            <div class="stat-label">Crops Covered</div>
            <div class="stat-value">4</div>
            <div class="stat-delta">Wheat · Rice · Maize · Cotton</div>
        </div>""", unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div class="stat-card">
            <div class="stat-label">Years of Data</div>
            <div class="stat-value">25</div>
            <div class="stat-delta">FAOSTAT 2000 – 2024</div>
        </div>""", unsafe_allow_html=True)
    with col3:
        st.markdown("""
        <div class="stat-card">
            <div class="stat-label">ML Models</div>
            <div class="stat-value">10+</div>
            <div class="stat-delta">Classification · Regression · Clustering</div>
        </div>""", unsafe_allow_html=True)
    with col4:
        st.markdown("""
        <div class="stat-card">
            <div class="stat-label">Datasets Used</div>
            <div class="stat-value">3</div>
            <div class="stat-delta">Disease · Yield · Raisin</div>
        </div>""", unsafe_allow_html=True)
 
    st.markdown("<br>", unsafe_allow_html=True)
 
    # Dataset + model info
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("""
        <div class="elegantcard">
            <div class="section-eyebrow">Datasets</div>
            <div class="section-title" style="font-size:1.2rem;">Data Sources</div>
            <div style="color:var(--text-secondary); font-size:0.88rem; line-height:2;">
                <span style="color:var(--gold);">◆</span> <strong style="color:var(--text-primary);">Wheat Disease</strong><br>
                &nbsp;&nbsp;&nbsp;43 samples · 4 features · SMOTE applied<br>
                <span style="color:var(--blue);">◆</span> <strong style="color:var(--text-primary);">Pakistan FAOSTAT</strong><br>
                &nbsp;&nbsp;&nbsp;25 years · 4 crops · 5-Fold CV applied<br>
                <span style="color:var(--green);">◆</span> <strong style="color:var(--text-primary);">Raisin Dataset</strong><br>
                &nbsp;&nbsp;&nbsp;900 samples · 7 features · balanced
            </div>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div class="elegantcard">
            <div class="section-eyebrow">Models</div>
            <div class="section-title" style="font-size:1.2rem;">Algorithms Trained</div>
            <div style="color:var(--text-secondary); font-size:0.88rem; line-height:2;">
                <span style="color:var(--gold);">◆</span> <strong style="color:var(--text-primary);">Disease:</strong>
                Decision Tree · KNN · Random Forest (SMOTE)<br>
                <span style="color:var(--blue);">◆</span> <strong style="color:var(--text-primary);">Yield:</strong>
                Linear · Ridge · Random Forest · XGBoost<br>
                <span style="color:var(--green);">◆</span> <strong style="color:var(--text-primary);">Zones:</strong>
                KMeans (k=3 · Elbow + Silhouette validated)
            </div>
        </div>
        """, unsafe_allow_html=True)
 
    # Methodology note
    st.markdown("""
    <div class="info-box" style="margin-top:1rem;">
        <strong style="color:var(--gold); font-family:'Space Mono',monospace; font-size:10px; 
        letter-spacing:0.15em; text-transform:uppercase;">Methodological Transparency</strong><br><br>
        The wheat disease dataset has only 43 samples across 9+ classes — Cross-validation 
        and SMOTE were applied to handle this limitation. All regression models used 5-Fold CV 
        on the 25-row yield dataset. GridSearchCV tuned RF, SVM, Ridge, and KNN models. 
        Visit the <strong>Model Performance Dashboard</strong> for full metric breakdowns.
    </div>
    """, unsafe_allow_html=True)
 
# ────────────────────────────────────────────────────────────
# ── MODEL PERFORMANCE DASHBOARD ──────────────────────────
# ────────────────────────────────────────────────────────────
 
elif page == "📊 Model Performance Dashboard":
    st.markdown("""
    <div class="page-header">
        <div class="gold-tag">Evaluation · Metrics · Transparency</div>
        <div class="page-title">Model Performance<br>Dashboard</div>
        <div class="page-subtitle">Full evaluation metrics from all training pipelines</div>
    </div>
    """, unsafe_allow_html=True)
 
    tab1, tab2, tab3 = st.tabs([
        "  🔬  Disease Classification  ",
        "  📈  Yield Regression  ",
        "  🗺️  Clustering  "
    ])
 
    with tab1:
        st.markdown("""
        <div class="section-eyebrow">Classification · Wheat Disease</div>
        <div class="section-title">Wheat Disease Classification Results</div>
        """, unsafe_allow_html=True)
        st.markdown("""
        <div class="info-box">
            <strong>Methodology:</strong> Stratified 5-Fold Cross Validation + SMOTE oversampling.
            Dataset: 43 samples, 9+ classes — small and imbalanced.
            SMOTE applied inside each fold to prevent data leakage.
        </div>
        """, unsafe_allow_html=True)
        try:
            disease_res = pd.read_csv("disease_classification_results.csv")
            st.dataframe(disease_res.style.highlight_max(
                subset=['F1_Score', 'Accuracy'], color='#1a2e1a'
            ).format({
                'Accuracy': '{:.4f}', 'F1_Score': '{:.4f}',
                'Precision': '{:.4f}', 'Recall': '{:.4f}'
            }), use_container_width=True)
 
            best_idx  = disease_res['F1_Score'].idxmax()
            best_name = disease_res.loc[best_idx, 'Model']
            best_f1   = disease_res.loc[best_idx, 'F1_Score']
            best_acc  = disease_res.loc[best_idx, 'Accuracy']
            st.markdown(f"""
            <div class="success-box">
                <span style="font-family:'Space Mono',monospace;font-size:9px;letter-spacing:0.15em;
                text-transform:uppercase;color:var(--green);">🏆 Best Model</span><br>
                <strong style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;color:var(--text-primary);">
                {best_name}</strong><br>
                <span style="font-size:13px;color:var(--text-secondary);">
                F1 Score: <strong>{best_f1:.4f}</strong> &nbsp;·&nbsp; Accuracy: <strong>{best_acc:.4f}</strong>
                </span>
            </div>
            """, unsafe_allow_html=True)
 
            st.markdown("""
            <div class="elegantcard" style="margin-top:1rem;">
                <div class="section-eyebrow">Interpretation</div>
                <div style="color:var(--text-secondary);font-size:0.88rem;line-height:2;">
                    <span style="color:var(--gold);">◆</span> Random Forest (Tuned) achieved the highest F1 with SMOTE, 
                    demonstrating ensemble robustness on limited data.<br>
                    <span style="color:var(--gold);">◆</span> KNN improved significantly after SMOTE corrected class imbalance.<br>
                    <span style="color:var(--gold);">◆</span> Decision Tree was competitive but more prone to overfitting.<br>
                    <span style="color:var(--gold);">◆</span> Results represent <strong style="color:var(--text-primary);">5-Fold CV averages</strong>, not a single split.
                </div>
            </div>
            """, unsafe_allow_html=True)
        except FileNotFoundError:
            st.markdown('<div class="warning-box">Run <code>classification_models.py</code> first to generate results.</div>', unsafe_allow_html=True)
 
        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("""
        <div class="section-eyebrow">Classification · Raisin Dataset</div>
        <div class="section-title">Raisin Classification Results</div>
        """, unsafe_allow_html=True)
        st.markdown('<div class="info-box">Methodology: Stratified 80/20 split + GridSearchCV tuning.</div>', unsafe_allow_html=True)
        try:
            raisin_res = pd.read_csv("raisin_classification_results.csv")
            cols_to_show = [c for c in raisin_res.columns if c in
                            ['Model', 'Accuracy', 'AUC', 'Precision', 'Recall', 'F1_Score']]
            st.dataframe(raisin_res[cols_to_show].style.highlight_max(
                subset=[c for c in cols_to_show if c != 'Model'], color='#1a2e1a'
            ).format({c: '{:.4f}' for c in cols_to_show if c != 'Model'}),
                use_container_width=True)
 
            best_r_idx  = raisin_res['F1_Score'].idxmax()
            best_r_name = raisin_res.loc[best_r_idx, 'Model']
            best_r_auc  = raisin_res.loc[best_r_idx, 'AUC'] if 'AUC' in raisin_res.columns else None
            auc_str = f"AUC: <strong>{best_r_auc:.4f}</strong>" if best_r_auc else ""
            st.markdown(f"""
            <div class="success-box">
                <span style="font-family:'Space Mono',monospace;font-size:9px;letter-spacing:0.15em;
                text-transform:uppercase;color:var(--green);">🏆 Best Model</span><br>
                <strong style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;color:var(--text-primary);">
                {best_r_name}</strong><br>
                <span style="font-size:13px;color:var(--text-secondary);">{auc_str}</span>
            </div>
            """, unsafe_allow_html=True)
        except FileNotFoundError:
            st.markdown('<div class="warning-box">Run <code>classification_models.py</code> first to generate results.</div>', unsafe_allow_html=True)
 
    with tab2:
        st.markdown("""
        <div class="section-eyebrow">Regression · FAOSTAT Yield Data</div>
        <div class="section-title">Crop Yield Regression Results — 5-Fold CV</div>
        """, unsafe_allow_html=True)
        st.markdown("""
        <div class="info-box">
            <strong>Methodology:</strong> 5-Fold Cross Validation with cross_val_predict.
            All 25 data points used in a leave-one-fold-out manner.
            StandardScaler applied for Ridge/Linear; unscaled for tree models.
            GridSearchCV used for Ridge and Random Forest.
        </div>
        """, unsafe_allow_html=True)
        try:
            reg_res = pd.read_csv("regression_results.csv")
            st.dataframe(reg_res.style.highlight_max(
                subset=['R2_Score'], color='#1a2e1a'
            ).highlight_min(
                subset=['RMSE', 'MAE'], color='#1a2e1a'
            ).format({
                'RMSE': '{:.2f}', 'MAE': '{:.2f}', 'R2_Score': '{:.4f}'
            }), use_container_width=True)
 
            best_r_idx  = reg_res['R2_Score'].idxmax()
            best_r_name = reg_res.loc[best_r_idx, 'Model']
            best_r2     = reg_res.loc[best_r_idx, 'R2_Score']
            best_rmse   = reg_res.loc[best_r_idx, 'RMSE']
            st.markdown(f"""
            <div class="success-box">
                <span style="font-family:'Space Mono',monospace;font-size:9px;letter-spacing:0.15em;
                text-transform:uppercase;color:var(--green);">🏆 Best Model</span><br>
                <strong style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;color:var(--text-primary);">
                {best_r_name}</strong><br>
                <span style="font-size:13px;color:var(--text-secondary);">
                R²: <strong>{best_r2:.4f}</strong> &nbsp;·&nbsp; RMSE: <strong>{best_rmse:.2f} hg/ha</strong>
                </span>
            </div>
            """, unsafe_allow_html=True)
 
            lr_row = reg_res[reg_res['Model'] == 'Linear Regression']
            if not lr_row.empty:
                lr_r2 = lr_row['R2_Score'].values[0]
                if lr_r2 < 0:
                    st.markdown(f"""
                    <div class="warning-box">
                        <strong style="font-family:'Space Mono',monospace;font-size:9px;letter-spacing:0.15em;
                        text-transform:uppercase;color:var(--amber);">⚠ Negative R² Explanation</strong><br><br>
                        Linear Regression R² = <strong>{lr_r2:.4f}</strong> — this model performs worse than 
                        predicting the mean yield. Only 25 data points cannot fit a linear model reliably; 
                        crop yields follow non-linear multi-decade trends. Regularization (Ridge) or ensemble 
                        methods (RF) are required for this type of time-series data.
                    </div>
                    """, unsafe_allow_html=True)
        except FileNotFoundError:
            st.markdown('<div class="warning-box">Run <code>regression_models.py</code> first to generate results.</div>', unsafe_allow_html=True)
 
    with tab3:
        st.markdown("""
        <div class="section-eyebrow">Unsupervised · K-Means</div>
        <div class="section-title">K-Means Clustering Results</div>
        """, unsafe_allow_html=True)
        st.markdown('<div class="info-box">K-Means applied on Pakistan crop yield data (2000–2024). k=3 selected via Elbow + Silhouette analysis.</div>', unsafe_allow_html=True)
        try:
            clustered_df = pd.read_csv("clustered_yield.csv")
            crop_cols_c = [c for c in clustered_df.columns
                           if c not in ['Year', 'Year_norm', 'Cluster']
                           and not c.endswith('_lag1')
                           and not c.endswith('_roll3')]
 
            from sklearn.preprocessing import StandardScaler as SS
            from sklearn.metrics import silhouette_score as ss_fn
            X_c = clustered_df[crop_cols_c].values
            X_c_scaled = SS().fit_transform(X_c)
            sil = ss_fn(X_c_scaled, clustered_df['Cluster'].values)
 
            col1, col2, col3 = st.columns(3)
            with col1:
                st.markdown(f"""
                <div class="stat-card">
                    <div class="stat-label">Silhouette Score</div>
                    <div class="stat-value">{sil:.4f}</div>
                    <div class="stat-delta">&gt;0.5 = Good separation</div>
                </div>""", unsafe_allow_html=True)
            with col2:
                st.markdown("""
                <div class="stat-card">
                    <div class="stat-label">Number of Clusters</div>
                    <div class="stat-value">3</div>
                    <div class="stat-delta">Elbow + Silhouette validated</div>
                </div>""", unsafe_allow_html=True)
            with col3:
                st.markdown(f"""
                <div class="stat-card">
                    <div class="stat-label">Data Points</div>
                    <div class="stat-value">{len(clustered_df)}</div>
                    <div class="stat-delta">Years 2000 – 2024</div>
                </div>""", unsafe_allow_html=True)
 
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown('<div class="section-eyebrow">Cluster Summary</div>', unsafe_allow_html=True)
            cluster_stats = clustered_df.groupby('Cluster')[crop_cols_c].mean().round(0)
            cluster_stats.index = [f'Cluster {i}' for i in cluster_stats.index]
            st.dataframe(cluster_stats, use_container_width=True)
 
            st.markdown('<div class="section-eyebrow" style="margin-top:1.5rem;">Composition</div>', unsafe_allow_html=True)
            cluster_comp = clustered_df.groupby('Cluster').agg(
                Count=('Year', 'count'),
                Year_Min=('Year', 'min'),
                Year_Max=('Year', 'max')
            ).reset_index()
            cluster_comp.columns = ['Cluster', 'Sample Count', 'Earliest Year', 'Latest Year']
            st.dataframe(cluster_comp, use_container_width=True)
 
        except FileNotFoundError:
            st.markdown('<div class="warning-box">Run <code>clusturing.py</code> first to generate results.</div>', unsafe_allow_html=True)
 
# ────────────────────────────────────────────────────────────
# ── DISEASE RISK CHECKER ──────────────────────────────────
# ────────────────────────────────────────────────────────────
 
elif page == "🔬 Disease Risk Checker":
    st.markdown("""
    <div class="page-header">
        <div class="gold-tag">AI Diagnosis · Plant Pathology</div>
        <div class="page-title">Wheat Disease<br>Risk Checker</div>
        <div class="page-subtitle">Identify wheat diseases from visible plant symptoms using machine learning</div>
    </div>
    """, unsafe_allow_html=True)
 
    try:
        disease_res = pd.read_csv("disease_classification_results.csv")
        best_idx = disease_res['F1_Score'].idxmax()
        best_f1  = disease_res.loc[best_idx, 'F1_Score']
        best_acc = disease_res.loc[best_idx, 'Accuracy']
        best_nm  = disease_res.loc[best_idx, 'Model']
        st.markdown(f"""
        <div class="info-box">
            <span style="font-family:'Space Mono',monospace;font-size:9px;letter-spacing:0.15em;
            text-transform:uppercase;color:var(--blue);">Active Model</span><br>
            <strong style="color:var(--text-primary);">{best_nm}</strong> &nbsp;·&nbsp;
            5-Fold CV F1: <strong>{best_f1:.2%}</strong> &nbsp;·&nbsp; Accuracy: <strong>{best_acc:.2%}</strong><br>
            <span style="font-size:12px;color:var(--text-muted);">
            Evaluated using 5-Fold Stratified CV + SMOTE on 43-sample dataset.
            Predictions are decision-support tools, not clinical diagnoses.
            </span>
        </div>
        """, unsafe_allow_html=True)
    except Exception:
        st.markdown('<div class="warning-box">⚠ Model metrics unavailable. Run classification_models.py first.</div>', unsafe_allow_html=True)
 
    try:
        disease_model    = joblib.load("best_disease_model.pkl")
        disease_encoders = joblib.load("disease_encoders.pkl")
 
        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("""
        <div class="section-eyebrow">Input</div>
        <div class="section-title">Enter Plant Symptoms</div>
        """, unsafe_allow_html=True)
 
        col1, col2, col3 = st.columns(3)
        with col1:
            part = st.selectbox("🌱 Plant Part Affected",
                                options=disease_encoders['Part'].classes_,
                                help="Select which part of the plant shows symptoms")
        with col2:
            color = st.selectbox("🎨 Observed Color",
                                 options=disease_encoders['Color'].classes_,
                                 help="Select the color of the affected area")
        with col3:
            appearance = st.selectbox("🔍 Appearance Pattern",
                                      options=disease_encoders['Apperance_Of_Part'].classes_,
                                      help="Select the visual appearance pattern")
 
        st.markdown("<br>", unsafe_allow_html=True)
 
        if st.button("🔍 Analyse Disease Risk", use_container_width=True):
            with st.spinner("Analysing symptoms with AI model..."):
                part_enc       = disease_encoders['Part'].transform([part])[0]
                color_enc      = disease_encoders['Color'].transform([color])[0]
                appearance_enc = disease_encoders['Apperance_Of_Part'].transform([appearance])[0]
 
                input_features = np.array([[part_enc, color_enc, appearance_enc]])
                prediction     = disease_model.predict(input_features)[0]
                disease_name   = disease_encoders['WheatDisease'].inverse_transform([prediction])[0]
 
                if hasattr(disease_model, 'predict_proba'):
                    proba      = disease_model.predict_proba(input_features)[0]
                    confidence = float(np.max(proba))
                    top3_idx   = np.argsort(proba)[::-1][:3]
                    top3_names = disease_encoders['WheatDisease'].inverse_transform(top3_idx)
                    top3_probs = proba[top3_idx]
                else:
                    confidence = None
 
            st.markdown("<hr>", unsafe_allow_html=True)
            st.markdown("""
            <div class="section-eyebrow">Result</div>
            <div class="section-title">Prediction Result</div>
            """, unsafe_allow_html=True)
 
            col_res1, col_res2 = st.columns([2, 1])
            with col_res1:
                if 'healthy' in disease_name.lower():
                    st.markdown(f"""
                    <div class="result-healthy">
                        <div class="result-label">✅ Plant Status</div>
                        <div class="result-value">{disease_name}</div>
                        <div style="color:var(--green);font-size:13px;margin-top:0.5rem;">
                            Your plant appears healthy. Continue regular monitoring.
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="result-disease">
                        <div class="result-label">⚠ Detected Condition</div>
                        <div class="result-value">{disease_name}</div>
                        <div style="color:var(--red);font-size:13px;margin-top:0.5rem;">
                            Disease detected — immediate action recommended.
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
 
                    disease_advice = {
                        'rust':   '🌿 Rust is a fungal disease. Apply triazole fungicides.',
                        'stem':   '🌿 Stem rust spreads rapidly. Remove affected plants immediately.',
                        'leaf':   '🍃 Leaf disease detected. Remove affected leaves and check nutrients.',
                        'blight': '🔴 Blight spreads fast. Apply copper-based fungicide promptly.',
                        'mildew': '⚪ Powdery mildew — avoid overhead irrigation.',
                        'smut':   '⬛ Smut — use certified disease-free seeds next season.',
                        'yellow': '🟡 Yellow rust — apply propiconazole fungicide.',
                    }
                    advice_shown = False
                    for key, advice in disease_advice.items():
                        if key in disease_name.lower():
                            st.markdown(f'<div class="warning-box"><strong>Treatment Advice:</strong> {advice}</div>', unsafe_allow_html=True)
                            advice_shown = True
                            break
                    if not advice_shown:
                        st.markdown('<div class="warning-box"><strong>General Advice:</strong> Consult your local agricultural extension officer.</div>', unsafe_allow_html=True)
 
            with col_res2:
                if confidence is not None:
                    if confidence >= 0.7:
                        badge_class = "conf-badge-high"
                        badge_text  = "High Confidence"
                    elif confidence >= 0.4:
                        badge_class = "conf-badge-med"
                        badge_text  = "Moderate"
                    else:
                        badge_class = "conf-badge-low"
                        badge_text  = "Low — Verify"
 
                    st.markdown(f"""
                    <div class="elegantcard" style="text-align:center;">
                        <div class="stat-label">Prediction Confidence</div>
                        <div class="stat-value">{confidence:.0%}</div>
                        <div><span class="{badge_class}">{badge_text}</span></div>
                    </div>
                    """, unsafe_allow_html=True)
 
            if confidence is not None and hasattr(disease_model, 'predict_proba'):
                st.markdown("<hr>", unsafe_allow_html=True)
                st.markdown("""
                <div class="section-eyebrow">Probability Breakdown</div>
                <div class="section-title">Top 3 Predicted Conditions</div>
                """, unsafe_allow_html=True)
                for rank, (name, prob) in enumerate(zip(top3_names, top3_probs)):
                    col_a, col_b = st.columns([3, 1])
                    with col_a:
                        st.progress(float(prob), text=f"#{rank+1}  {name}")
                    with col_b:
                        st.markdown(f"<div style='padding-top:8px;font-family:Space Mono,monospace;font-size:13px;color:var(--gold);'><strong>{prob:.1%}</strong></div>", unsafe_allow_html=True)
 
    except FileNotFoundError:
        st.markdown('<div class="error-box">⚠ Model file not found. Please run <code>classification_models.py</code> first.</div>', unsafe_allow_html=True)
        st.stop()
    except Exception as e:
        st.markdown(f'<div class="error-box">⚠ An error occurred: {e}</div>', unsafe_allow_html=True)
 
# ────────────────────────────────────────────────────────────
# ── YIELD PREDICTOR ───────────────────────────────────────
# ────────────────────────────────────────────────────────────
 
elif page == "📈 Yield Predictor":
    st.markdown("""
    <div class="page-header">
        <div class="gold-tag">Forecasting · Time-Series · FAOSTAT</div>
        <div class="page-title">Crop Yield<br>Predictor</div>
        <div class="page-subtitle">Forecast crop yields across Pakistan based on 25-year historical trends</div>
    </div>
    """, unsafe_allow_html=True)
 
    try:
        reg_res = pd.read_csv("regression_results.csv")
        best_idx_r = reg_res['R2_Score'].idxmax()
        best_r2_r  = reg_res.loc[best_idx_r, 'R2_Score']
        best_rm_r  = reg_res.loc[best_idx_r, 'RMSE']
        best_nm_r  = reg_res.loc[best_idx_r, 'Model']
        st.markdown(f"""
        <div class="info-box">
            <span style="font-family:'Space Mono',monospace;font-size:9px;letter-spacing:0.15em;
            text-transform:uppercase;color:var(--blue);">Active Model</span><br>
            <strong style="color:var(--text-primary);">Random Forest Regressor</strong> (per-crop · tuned via GridSearchCV)<br>
            Best CV R² (Wheat): <strong>{best_r2_r:.4f}</strong> &nbsp;·&nbsp; Best CV RMSE: <strong>{best_rm_r:.2f} hg/ha</strong><br>
            <span style="font-size:12px;color:var(--text-muted);">Evaluated using 5-Fold Cross Validation on 25-year FAOSTAT dataset.</span>
        </div>
        """, unsafe_allow_html=True)
    except Exception:
        st.markdown('<div class="info-box">Model info unavailable. Run regression_models.py first.</div>', unsafe_allow_html=True)
 
    try:
        crop_models = joblib.load("crop_models.pkl")
        yield_df    = pd.read_csv("cleaned_yield.csv")
        available_crops = list(crop_models.keys())
 
        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("""
        <div class="section-eyebrow">Parameters</div>
        <div class="section-title">Configure Prediction</div>
        """, unsafe_allow_html=True)
 
        col1, col2 = st.columns(2)
        with col1:
            prediction_year = st.slider("📅 Forecast Year",
                                        min_value=2025, max_value=2035,
                                        value=2026, step=1)
        with col2:
            selected_crop = st.selectbox("🌾 Select Crop", options=available_crops,
                                         help="Each crop uses its own dedicated prediction model")
 
        st.markdown("<br>", unsafe_allow_html=True)
 
        if st.button("📊 Generate Yield Forecast", use_container_width=True):
            with st.spinner(f"Forecasting {selected_crop} yield for {prediction_year}..."):
                crop_info    = crop_models[selected_crop]
                model        = crop_info['model']
                feature_cols = crop_info['feature_cols']
 
                last_row = yield_df.iloc[-1]
                input_values = [last_row[col] if col in last_row.index else 0 for col in feature_cols]
                input_array     = np.array(input_values).reshape(1, -1)
                predicted_yield = model.predict(input_array)[0]
 
                if selected_crop in yield_df.columns:
                    hist_avg   = yield_df[selected_crop].mean()
                    hist_max   = yield_df[selected_crop].max()
                    hist_min   = yield_df[selected_crop].min()
                    last_known = yield_df[selected_crop].iloc[-1]
                else:
                    hist_avg = hist_max = hist_min = last_known = predicted_yield
 
                change_vs_last = predicted_yield - last_known
                trend_icon = "📈" if change_vs_last >= 0 else "📉"
                trend_text = (f"+{change_vs_last:.0f}" if change_vs_last >= 0 else f"{change_vs_last:.0f}")
 
                try:
                    reg_res = pd.read_csv("regression_results.csv")
                    rf_row  = reg_res[reg_res['Model'].str.contains('Random Forest', na=False)]
                    rmse_est = float(rf_row['RMSE'].values[0]) if len(rf_row) > 0 else 200
                except Exception:
                    rmse_est = 200
 
            st.markdown("<hr>", unsafe_allow_html=True)
            st.markdown("""
            <div class="section-eyebrow">Forecast Output</div>
            <div class="section-title">Prediction Result</div>
            """, unsafe_allow_html=True)
 
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.markdown(f"""
                <div class="stat-card">
                    <div class="stat-label">{selected_crop} Yield ({prediction_year})</div>
                    <div class="stat-value">{predicted_yield:,.0f}</div>
                    <div class="stat-delta">hg/ha &nbsp; {trend_icon} {trend_text} vs {int(yield_df['Year'].iloc[-1])}</div>
                </div>""", unsafe_allow_html=True)
            with col2:
                st.markdown(f"""
                <div class="stat-card">
                    <div class="stat-label">Historical Average</div>
                    <div class="stat-value">{hist_avg:,.0f}</div>
                    <div class="stat-delta">hg/ha</div>
                </div>""", unsafe_allow_html=True)
            with col3:
                st.markdown(f"""
                <div class="stat-card">
                    <div class="stat-label">Historical Maximum</div>
                    <div class="stat-value">{hist_max:,.0f}</div>
                    <div class="stat-delta">hg/ha</div>
                </div>""", unsafe_allow_html=True)
            with col4:
                st.markdown(f"""
                <div class="stat-card">
                    <div class="stat-label">Historical Minimum</div>
                    <div class="stat-value">{hist_min:,.0f}</div>
                    <div class="stat-delta">hg/ha</div>
                </div>""", unsafe_allow_html=True)
 
            st.markdown(f"""
            <div style="margin:1.5rem 0 0.4rem 0;">
                <span style="font-family:'Space Mono',monospace;font-size:10px;letter-spacing:0.12em;
                text-transform:uppercase;color:var(--text-muted);">
                {trend_icon} Predicted yield vs. historical maximum
                </span>
            </div>
            """, unsafe_allow_html=True)
            progress_val = min(predicted_yield / hist_max, 1.0) if hist_max > 0 else 0.5
            st.progress(progress_val)
            st.markdown(f"""
            <div style="display:flex;justify-content:space-between;margin-top:4px;">
                <span style="font-size:11px;color:var(--text-muted);">
                    {progress_val*100:.1f}% of historical maximum
                </span>
                <span style="font-size:11px;color:var(--text-muted);">
                    ±1 RMSE interval: {max(0, predicted_yield-rmse_est):,.0f} – {predicted_yield+rmse_est:,.0f} hg/ha
                </span>
            </div>
            """, unsafe_allow_html=True)
 
            if selected_crop in yield_df.columns:
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown(f"""
                <div class="section-eyebrow">Time Series</div>
                <div class="section-title">{selected_crop} — Historical + Forecast</div>
                """, unsafe_allow_html=True)
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=yield_df['Year'], y=yield_df[selected_crop],
                    mode='lines+markers', name='Historical Yield',
                    line=dict(color='#C9A84C', width=2.5),
                    marker=dict(size=6, color='#C9A84C', line=dict(width=1, color='#0A0D0F'))
                ))
                fig.add_trace(go.Scatter(
                    x=[prediction_year, prediction_year],
                    y=[predicted_yield - rmse_est, predicted_yield + rmse_est],
                    mode='lines', name='±1 RMSE Interval',
                    line=dict(color='#E05555', width=2, dash='dot')
                ))
                fig.add_trace(go.Scatter(
                    x=[prediction_year], y=[predicted_yield],
                    mode='markers', name=f'Forecast {prediction_year}',
                    marker=dict(color='#E05555', size=14, symbol='star',
                                line=dict(width=1.5, color='#0A0D0F'))
                ))
                fig.update_layout(
                    **PLOTLY_LAYOUT,
                    title=f'{selected_crop} Yield: 2000–{prediction_year}',
                    xaxis_title='Year', yaxis_title='Yield (hg/ha)', height=420
                )
                st.plotly_chart(fig, use_container_width=True)
 
            st.markdown(f"""
            <div class="elegantcard" style="margin-top:1rem;">
                <div class="section-eyebrow">Summary</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.6rem 2rem;
                color:var(--text-secondary);font-size:0.88rem;line-height:2;">
                    <div><span style="color:var(--text-muted);">Crop</span><br>
                    <strong style="color:var(--text-primary);">{selected_crop}</strong></div>
                    <div><span style="color:var(--text-muted);">Forecast Year</span><br>
                    <strong style="color:var(--text-primary);">{prediction_year}</strong></div>
                    <div><span style="color:var(--text-muted);">Predicted Yield</span><br>
                    <strong style="color:var(--gold);">{predicted_yield:,.0f} hg/ha</strong></div>
                    <div><span style="color:var(--text-muted);">CV R² / RMSE</span><br>
                    <strong style="color:var(--text-primary);">{best_r2_r:.4f} / {rmse_est:.0f}</strong></div>
                </div>
                <div class="info-box" style="margin-top:1rem;">
                    Predictions are extrapolations. External factors (weather, policy, infrastructure) 
                    are not modelled and could cause actual yields to differ materially.
                </div>
            </div>
            """, unsafe_allow_html=True)
 
    except FileNotFoundError:
        st.markdown('<div class="error-box">⚠ Model file <code>crop_models.pkl</code> not found. Run <code>regression_models.py</code> first, then restart the app.</div>', unsafe_allow_html=True)
        st.stop()
    except Exception as e:
        import traceback
        st.markdown(f'<div class="error-box">⚠ Error in Yield Predictor: {e}</div>', unsafe_allow_html=True)
        st.code(traceback.format_exc())
 
# ────────────────────────────────────────────────────────────
# ── CROP ZONE INSIGHTS ────────────────────────────────────
# ────────────────────────────────────────────────────────────
 
elif page == "🗺️ Crop Zone Insights":
    st.markdown("""
    <div class="page-header">
        <div class="gold-tag">Unsupervised Learning · K-Means · Temporal Analysis</div>
        <div class="page-title">Crop Zone<br>Insights</div>
        <div class="page-subtitle">Yield patterns discovered through K-Means clustering across Pakistan's agricultural history</div>
    </div>
    """, unsafe_allow_html=True)
 
    try:
        clustered_df = pd.read_csv("clustered_yield.csv")
        from sklearn.preprocessing import StandardScaler as SS
        from sklearn.metrics import silhouette_score as ss_fn
        crop_cols_c = [c for c in clustered_df.columns
                       if c not in ['Year', 'Year_norm', 'Cluster']
                       and not c.endswith('_lag1')
                       and not c.endswith('_roll3')]
        X_c = SS().fit_transform(clustered_df[crop_cols_c].values)
        sil = ss_fn(X_c, clustered_df['Cluster'].values)
 
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-label">Silhouette Score</div>
                <div class="stat-value">{sil:.4f}</div>
                <div class="stat-delta">&gt;0.5 = Good cluster separation</div>
            </div>""", unsafe_allow_html=True)
        with col2:
            st.markdown("""
            <div class="stat-card">
                <div class="stat-label">Clusters Identified</div>
                <div class="stat-value">3</div>
                <div class="stat-delta">Low · Medium · High Yield</div>
            </div>""", unsafe_allow_html=True)
        with col3:
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-label">Data Points</div>
                <div class="stat-value">{len(clustered_df)}</div>
                <div class="stat-delta">Annual observations</div>
            </div>""", unsafe_allow_html=True)
 
        st.markdown("""
        <div class="info-box" style="margin-top:1.5rem;">
            K-Means clustering grouped Pakistan's 25 years of crop data into <strong>3 natural yield zones</strong>:<br>
            <span style="color:#4A90D9;">◆ Cluster 0</span> — Low Yield Zone &nbsp;·&nbsp;
            <span style="color:#E8A838;">◆ Cluster 1</span> — Medium Yield Zone &nbsp;·&nbsp;
            <span style="color:#4CAF7D;">◆ Cluster 2</span> — High Yield Zone
        </div>
        """, unsafe_allow_html=True)
 
        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("""
        <div class="section-eyebrow">Visualisation</div>
        <div class="section-title">Interactive Cluster Plot</div>
        """, unsafe_allow_html=True)
 
        if len(crop_cols_c) >= 2:
            col1, col2 = st.columns(2)
            with col1:
                x_axis = st.selectbox("X Axis (Crop)", options=crop_cols_c, index=0)
            with col2:
                y_axis = st.selectbox("Y Axis (Crop)", options=crop_cols_c,
                                      index=min(1, len(crop_cols_c)-1))
 
            fig = px.scatter(
                clustered_df, x=x_axis, y=y_axis,
                color=clustered_df['Cluster'].astype(str),
                color_discrete_map={'0': '#4A90D9', '1': '#E8A838', '2': '#4CAF7D'},
                title=f'{x_axis} vs {y_axis} — Yield Zones',
                labels={'color': 'Zone'},
                hover_data=['Year'] if 'Year' in clustered_df.columns else [],
            )
            fig.update_traces(marker=dict(size=11, opacity=0.85,
                                          line=dict(width=1, color='rgba(10,13,15,0.6)')))
            fig.update_layout(**PLOTLY_LAYOUT, height=480)
            st.plotly_chart(fig, use_container_width=True)
 
        if 'Year' in clustered_df.columns and len(crop_cols_c) > 0:
            st.markdown("<hr>", unsafe_allow_html=True)
            st.markdown("""
            <div class="section-eyebrow">Timeline</div>
            <div class="section-title">Yield Zones Over Time</div>
            """, unsafe_allow_html=True)
            selected_crop_plot = st.selectbox("Select Crop for Timeline:", options=crop_cols_c)
            fig2 = px.scatter(
                clustered_df, x='Year', y=selected_crop_plot,
                color=clustered_df['Cluster'].astype(str),
                color_discrete_map={'0': '#4A90D9', '1': '#E8A838', '2': '#4CAF7D'},
                title=f'{selected_crop_plot} Yield Over Time — by Zone',
                labels={'color': 'Zone'}
            )
            fig2.update_traces(marker=dict(size=11, opacity=0.85,
                                            line=dict(width=1, color='rgba(10,13,15,0.6)')))
            fig2.update_layout(**PLOTLY_LAYOUT, height=400)
            st.plotly_chart(fig2, use_container_width=True)
 
        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("""
        <div class="section-eyebrow">Statistics</div>
        <div class="section-title">Cluster Summary</div>
        """, unsafe_allow_html=True)
        cluster_stats = clustered_df.groupby('Cluster')[crop_cols_c].mean().round(0)
        st.dataframe(cluster_stats, use_container_width=True)
 
        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("""
        <div class="section-eyebrow">Zone Profiles</div>
        <div class="section-title">Zone Characteristics</div>
        """, unsafe_allow_html=True)
        cols = st.columns(3)
        overall_avg = clustered_df[crop_cols_c].mean().mean()
        zone_styles = [
            ('#1A2A3D', '#4A90D9', '◆ Low Yield Zone'),
            ('#3D2E10', '#E8A838', '◆ Medium Yield Zone'),
            ('#1E3D2C', '#4CAF7D', '◆ High Yield Zone'),
        ]
        for i, cluster_id in enumerate([0, 1, 2]):
            cluster_data = clustered_df[clustered_df['Cluster'] == cluster_id]
            cluster_avg  = cluster_stats.loc[cluster_id].mean() if cluster_id in cluster_stats.index else overall_avg
            bg, accent, label = zone_styles[i]
            year_range = ""
            if 'Year' in clustered_df.columns and len(cluster_data) > 0:
                years = sorted(cluster_data['Year'].tolist())
                year_range = f"{years[0]}–{years[-1]}" if len(years) > 1 else str(years[0])
            with cols[i]:
                st.markdown(f"""
                <div class="zone-card" style="background:{bg};border-color:{accent}40;">
                    <div class="zone-card-label" style="color:{accent};">Cluster {cluster_id}</div>
                    <div class="zone-card-title" style="color:{accent};">{label}</div>
                    <div class="zone-card-stat">
                        <span style="color:var(--text-muted);">Avg Yield</span><br>
                        <strong style="color:var(--text-primary);">{cluster_avg:,.0f} hg/ha</strong>
                    </div>
                    <div class="zone-card-stat" style="margin-top:6px;">
                        <span style="color:var(--text-muted);">Years</span> 
                        <strong style="color:var(--text-primary);">{len(cluster_data)}</strong>
                        &nbsp;·&nbsp;
                        <span style="color:var(--text-muted);">Period</span>
                        <strong style="color:var(--text-primary);">{year_range}</strong>
                    </div>
                </div>
                """, unsafe_allow_html=True)
 
    except FileNotFoundError:
        st.markdown('<div class="error-box">⚠ Clustered data not found. Please run <code>clusturing.py</code> first.</div>', unsafe_allow_html=True)
        st.stop()
    except Exception as e:
        st.markdown(f'<div class="error-box">⚠ Error: {e}</div>', unsafe_allow_html=True)
 
# ────────────────────────────────────────────────────────────
# ── COMPARATIVE ANALYSIS ──────────────────────────────────
# ────────────────────────────────────────────────────────────
 
elif page == "🔍 Comparative Analysis":
    st.markdown("""
    <div class="page-header">
        <div class="gold-tag">Cross-Task · Insights · Conclusions</div>
        <div class="page-title">Comparative<br>Analysis</div>
        <div class="page-subtitle">Cross-task model comparisons, preprocessing impact, and key findings</div>
    </div>
    """, unsafe_allow_html=True)
 
    st.markdown("""
    <div class="section-eyebrow">Finding 01</div>
    <div class="section-title">Ensemble Models Outperformed All Others</div>
    <div class="elegantcard">
        <div style="color:var(--text-secondary);font-size:0.9rem;line-height:2;">
            Random Forest achieved the best performance in <strong style="color:var(--text-primary);">every single task</strong>:<br>
            <span style="color:var(--gold);">◆</span> Classification (Disease): Highest F1 with SMOTE<br>
            <span style="color:var(--gold);">◆</span> Classification (Raisin): Highest AUC<br>
            <span style="color:var(--gold);">◆</span> Regression (Yield): Highest R² score<br><br>
            This confirms ensemble methods are the most reliable choice for agricultural ML across 
            both small and medium-sized tabular datasets.
        </div>
    </div>
    """, unsafe_allow_html=True)
 
    st.markdown("""
    <div class="section-eyebrow" style="margin-top:2rem;">Finding 02</div>
    <div class="section-title">Dataset Size Drove Evaluation Strategy</div>
    """, unsafe_allow_html=True)
 
    st.markdown("""
    | Dataset | Size | Strategy | Reason |
    |---------|------|----------|--------|
    | Disease | 43 rows | Stratified K-Fold CV + SMOTE | Too small; class imbalanced |
    | Yield | 25 rows | 5-Fold CV | Too small for train/test split |
    | Raisin | 900 rows | Stratified 80/20 split | Sufficient for standard split |
    """)
 
    st.markdown("""
    <div class="section-eyebrow" style="margin-top:2rem;">Finding 03</div>
    <div class="section-title">Linear Regression Failed on Non-Linear Data</div>
    <div class="warning-box">
        Linear Regression on crop yield data produced <strong>R² = −0.22</strong> — worse than predicting 
        the mean every year. Ridge regularization improved this to R² ≈ 0.71. Random Forest further improved 
        to R² ≈ 0.74 by capturing non-linear patterns. <strong>Non-linear models are mandatory for time-series yield data.</strong>
    </div>
    """, unsafe_allow_html=True)
 
    st.markdown("""
    <div class="section-eyebrow" style="margin-top:2rem;">Finding 04</div>
    <div class="section-title">Preprocessing Impact</div>
    """, unsafe_allow_html=True)
 
    st.markdown("""
    | Technique | Applied To | Effect |
    |-----------|------------|--------|
    | StandardScaler | Raisin + Yield (Ridge/LR) | Required for SVM, LR, Ridge |
    | SMOTE | Disease classification | Corrected 43-sample class imbalance |
    | Lag features | Yield regression | Encoded temporal autocorrelation |
    | Rolling mean | Yield regression | Captured 3-year trend momentum |
    | LabelEncoder | Disease features | Converted categorical to numeric |
    """)
 
    st.markdown("""
    <div class="section-eyebrow" style="margin-top:2rem;">Finding 05</div>
    <div class="section-title">GridSearchCV Tuning Impact</div>
    <div class="elegantcard">
        <div style="color:var(--text-secondary);font-size:0.9rem;line-height:2;">
            All tuned models outperformed their default-parameter baselines:<br>
            <span style="color:var(--gold);">◆</span> <strong style="color:var(--text-primary);">SVM:</strong> kernel and C selection critical for raisin classification<br>
            <span style="color:var(--gold);">◆</span> <strong style="color:var(--text-primary);">Ridge:</strong> optimal alpha prevented underfitting on 25-row yield data<br>
            <span style="color:var(--gold);">◆</span> <strong style="color:var(--text-primary);">Random Forest:</strong> depth control prevented overfitting on small datasets
        </div>
    </div>
    """, unsafe_allow_html=True)
 
    st.markdown("""
    <div class="section-eyebrow" style="margin-top:2rem;">Finding 06</div>
    <div class="section-title">Unsupervised Learning Complemented Supervised Results</div>
    <div class="elegantcard">
        <div style="color:var(--text-secondary);font-size:0.9rem;line-height:2;">
            K-Means clustering (silhouette &gt; 0.5) revealed 3 distinct agricultural productivity eras 
            in Pakistan's 2000–2024 data <em>without any labels</em>. This temporal segmentation explains 
            structural yield jumps observed in the regression task, providing interpretable context for predictions.
        </div>
    </div>
    """, unsafe_allow_html=True)
 
    st.markdown("""
    <div class="success-box" style="margin-top:2rem;">
        <span style="font-family:'Space Mono',monospace;font-size:9px;letter-spacing:0.15em;
        text-transform:uppercase;color:var(--green);">🏆 Overall Conclusion</span><br><br>
        <strong style="color:var(--text-primary);">Model selection and preprocessing must be driven by dataset characteristics</strong> 
        — size, balance, and linearity. Random Forest with GridSearchCV tuning is the most robust approach 
        across all three agricultural ML tasks in this project.
    </div>
    """, unsafe_allow_html=True)
 
# ────────────────────────────────────────────────────────────
# ── FOOTER ────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────
 
st.markdown("""
<div class="app-footer">
    <div class="app-footer-text">
        Pakistan Crop Intelligence System &nbsp;·&nbsp; CS-245 Machine Learning Project<br>
        Classification &nbsp;·&nbsp; Regression &nbsp;·&nbsp; Clustering
    </div>
</div>
""", unsafe_allow_html=True)